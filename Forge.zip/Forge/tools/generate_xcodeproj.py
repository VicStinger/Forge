#!/usr/bin/env python3
"""Generate Forge.xcodeproj.

This is a line-for-line port of Forge/Services/XcodeProjectGenerator.swift, so the
app's own project file has exactly the shape of the projects the app exports.
The only difference is EXTRA_TARGET_SETTINGS, which turns on Files-app access to
the Projects folder.

Usage:  python3 tools/generate_xcodeproj.py
"""
import os
import sys

MODULE = "Forge"
DISPLAY_NAME = "Forge"
BUNDLE_ID = "com.example.Forge"
DEPLOYMENT_TARGET = "17.0"
VERSION = "1.0"

# Lets the user see and back up their projects from the Files app.
EXTRA_TARGET_SETTINGS = {
    "INFOPLIST_KEY_UIFileSharingEnabled": "YES",
    "INFOPLIST_KEY_LSSupportsOpeningDocumentsInPlace": "YES",
}


def fnv(s: str) -> int:
    h = 0xCBF29CE484222325
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return h


def oid(seed: str) -> str:
    return "%016X" % fnv(seed) + ("%016X" % fnv(seed + "#"))[:8]


def quote(v: str) -> str:
    plain = bool(v) and all(c.isascii() and (c.isalnum() or c in "_./") for c in v)
    if plain:
        return v
    v = v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return '"%s"' % v


def build_phase(i, isa, comment):
    return ("\t\t%s /* %s */ = {\n\t\t\tisa = %s;\n\t\t\tbuildActionMask = 2147483647;\n"
            "\t\t\tfiles = (\n\t\t\t);\n\t\t\trunOnlyForDeploymentPostprocessing = 0;\n\t\t};\n") % (i, comment, isa)


def config(i, name, settings):
    s = "\t\t%s /* %s */ = {\n\t\t\tisa = XCBuildConfiguration;\n\t\t\tbuildSettings = {\n" % (i, name)
    for key in sorted(settings):
        v = settings[key]
        if isinstance(v, list):
            s += "\t\t\t\t%s = (\n" % key
            for item in v:
                s += "\t\t\t\t\t%s,\n" % quote(item)
            s += "\t\t\t\t);\n"
        else:
            s += "\t\t\t\t%s = %s;\n" % (key, quote(v))
    s += "\t\t\t};\n\t\t\tname = %s;\n\t\t};\n" % name
    return s


def config_list(i, kind, name, debug, release):
    return ("\t\t%s /* Build configuration list for %s \"%s\" */ = {\n\t\t\tisa = XCConfigurationList;\n"
            "\t\t\tbuildConfigurations = (\n\t\t\t\t%s /* Debug */,\n\t\t\t\t%s /* Release */,\n\t\t\t);\n"
            "\t\t\tdefaultConfigurationIsVisible = 0;\n\t\t\tdefaultConfigurationName = Release;\n\t\t};\n"
            ) % (i, kind, name, debug, release)


def project_settings(debug):
    s = {
        "ALWAYS_SEARCH_USER_PATHS": "NO",
        "ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS": "YES",
        "CLANG_ANALYZER_NONNULL": "YES",
        "CLANG_ENABLE_MODULES": "YES",
        "CLANG_ENABLE_OBJC_ARC": "YES",
        "CLANG_ENABLE_OBJC_WEAK": "YES",
        "CLANG_WARN_DOCUMENTATION_COMMENTS": "YES",
        "CLANG_WARN_EMPTY_BODY": "YES",
        "CLANG_WARN_UNGUARDED_AVAILABILITY": "YES_AGGRESSIVE",
        "ENABLE_STRICT_OBJC_MSGSEND": "YES",
        "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
        "GCC_C_LANGUAGE_STANDARD": "gnu17",
        "GCC_NO_COMMON_BLOCKS": "YES",
        "GCC_WARN_UNUSED_VARIABLE": "YES",
        "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
        "LOCALIZATION_PREFERS_STRING_CATALOGS": "YES",
        "SDKROOT": "iphoneos",
    }
    if debug:
        s.update({
            "COPY_PHASE_STRIP": "NO",
            "DEBUG_INFORMATION_FORMAT": "dwarf",
            "ENABLE_TESTABILITY": "YES",
            "GCC_DYNAMIC_NO_PIC": "NO",
            "GCC_OPTIMIZATION_LEVEL": "0",
            "GCC_PREPROCESSOR_DEFINITIONS": ["DEBUG=1", "$(inherited)"],
            "MTL_ENABLE_DEBUG_INFO": "INCLUDE_SOURCE",
            "ONLY_ACTIVE_ARCH": "YES",
            "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG $(inherited)",
            "SWIFT_OPTIMIZATION_LEVEL": "-Onone",
        })
    else:
        s.update({
            "COPY_PHASE_STRIP": "NO",
            "DEBUG_INFORMATION_FORMAT": "dwarf-with-dsym",
            "ENABLE_NS_ASSERTIONS": "NO",
            "MTL_ENABLE_DEBUG_INFO": "NO",
            "SWIFT_COMPILATION_MODE": "wholemodule",
            "VALIDATE_PRODUCT": "YES",
        })
    return s


def target_settings():
    s = {
        "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
        "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
        "CODE_SIGN_STYLE": "Automatic",
        "CURRENT_PROJECT_VERSION": "1",
        "ENABLE_PREVIEWS": "YES",
        "GENERATE_INFOPLIST_FILE": "YES",
        "INFOPLIST_KEY_CFBundleDisplayName": DISPLAY_NAME,
        "INFOPLIST_KEY_UIApplicationSceneManifest_Generation": "YES",
        "INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents": "YES",
        "INFOPLIST_KEY_UILaunchScreen_Generation": "YES",
        "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad":
            "UIInterfaceOrientationPortrait UIInterfaceOrientationPortraitUpsideDown "
            "UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight",
        "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone":
            "UIInterfaceOrientationPortrait UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight",
        "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
        "MARKETING_VERSION": VERSION,
        "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID,
        "PRODUCT_NAME": "$(TARGET_NAME)",
        "SWIFT_EMIT_LOC_STRINGS": "YES",
        "SWIFT_VERSION": "5.0",
        "TARGETED_DEVICE_FAMILY": "1,2",
    }
    s.update(EXTRA_TARGET_SETTINGS)
    return s


def pbxproj():
    m = MODULE
    seed = "forge." + m
    product_ref = oid(seed + ".product")
    main_group = oid(seed + ".mainGroup")
    sources_group = oid(seed + ".sourcesGroup")
    products_grp = oid(seed + ".productsGroup")
    target = oid(seed + ".target")
    project = oid(seed + ".project")
    src_phase = oid(seed + ".phase.sources")
    fw_phase = oid(seed + ".phase.frameworks")
    res_phase = oid(seed + ".phase.resources")
    proj_cfg_list = oid(seed + ".cfglist.project")
    tgt_cfg_list = oid(seed + ".cfglist.target")
    proj_debug = oid(seed + ".cfg.project.debug")
    proj_release = oid(seed + ".cfg.project.release")
    tgt_debug = oid(seed + ".cfg.target.debug")
    tgt_release = oid(seed + ".cfg.target.release")
    q = quote(m)

    o = "// !$*UTF8*$!\n{\n"
    o += "\tarchiveVersion = 1;\n\tclasses = {\n\t};\n\tobjectVersion = 77;\n\tobjects = {\n\n"

    o += "/* Begin PBXFileReference section */\n"
    o += ("\t\t%s /* %s.app */ = {isa = PBXFileReference; explicitFileType = wrapper.application; "
          "includeInIndex = 0; path = %s; sourceTree = BUILT_PRODUCTS_DIR; };\n") % (product_ref, m, quote(m + ".app"))
    o += "/* End PBXFileReference section */\n\n"

    o += "/* Begin PBXFileSystemSynchronizedRootGroup section */\n"
    o += ("\t\t%s /* %s */ = {\n\t\t\tisa = PBXFileSystemSynchronizedRootGroup;\n\t\t\tpath = %s;\n"
          "\t\t\tsourceTree = \"<group>\";\n\t\t};\n") % (sources_group, m, q)
    o += "/* End PBXFileSystemSynchronizedRootGroup section */\n\n"

    o += "/* Begin PBXFrameworksBuildPhase section */\n"
    o += build_phase(fw_phase, "PBXFrameworksBuildPhase", "Frameworks")
    o += "/* End PBXFrameworksBuildPhase section */\n\n"

    o += "/* Begin PBXGroup section */\n"
    o += ("\t\t%s = {\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n\t\t\t\t%s /* %s */,\n\t\t\t\t%s /* Products */,\n"
          "\t\t\t);\n\t\t\tsourceTree = \"<group>\";\n\t\t};\n") % (main_group, sources_group, m, products_grp)
    o += ("\t\t%s /* Products */ = {\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n\t\t\t\t%s /* %s.app */,\n"
          "\t\t\t);\n\t\t\tname = Products;\n\t\t\tsourceTree = \"<group>\";\n\t\t};\n") % (products_grp, product_ref, m)
    o += "/* End PBXGroup section */\n\n"

    o += "/* Begin PBXNativeTarget section */\n"
    o += "\t\t%s /* %s */ = {\n" % (target, m)
    o += "\t\t\tisa = PBXNativeTarget;\n"
    o += "\t\t\tbuildConfigurationList = %s /* Build configuration list for PBXNativeTarget \"%s\" */;\n" % (tgt_cfg_list, m)
    o += ("\t\t\tbuildPhases = (\n\t\t\t\t%s /* Sources */,\n\t\t\t\t%s /* Frameworks */,\n\t\t\t\t%s /* Resources */,\n\t\t\t);\n"
          % (src_phase, fw_phase, res_phase))
    o += "\t\t\tbuildRules = (\n\t\t\t);\n\t\t\tdependencies = (\n\t\t\t);\n"
    o += "\t\t\tfileSystemSynchronizedGroups = (\n\t\t\t\t%s /* %s */,\n\t\t\t);\n" % (sources_group, m)
    o += "\t\t\tname = %s;\n\t\t\tpackageProductDependencies = (\n\t\t\t);\n\t\t\tproductName = %s;\n" % (q, q)
    o += "\t\t\tproductReference = %s /* %s.app */;\n" % (product_ref, m)
    o += "\t\t\tproductType = \"com.apple.product-type.application\";\n\t\t};\n"
    o += "/* End PBXNativeTarget section */\n\n"

    o += "/* Begin PBXProject section */\n"
    o += "\t\t%s /* Project object */ = {\n\t\t\tisa = PBXProject;\n\t\t\tattributes = {\n" % project
    o += "\t\t\t\tBuildIndependentTargetsInParallel = 1;\n\t\t\t\tLastSwiftUpdateCheck = 1600;\n\t\t\t\tLastUpgradeCheck = 1600;\n"
    o += "\t\t\t\tTargetAttributes = {\n\t\t\t\t\t%s = {\n\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;\n\t\t\t\t\t};\n\t\t\t\t};\n\t\t\t};\n" % target
    o += "\t\t\tbuildConfigurationList = %s /* Build configuration list for PBXProject \"%s\" */;\n" % (proj_cfg_list, m)
    o += "\t\t\tdevelopmentRegion = en;\n\t\t\thasScannedForEncodings = 0;\n"
    o += "\t\t\tknownRegions = (\n\t\t\t\ten,\n\t\t\t\tBase,\n\t\t\t);\n"
    o += "\t\t\tmainGroup = %s;\n\t\t\tminimizedProjectReferenceProxies = 1;\n\t\t\tpreferredProjectObjectVersion = 77;\n" % main_group
    o += "\t\t\tproductRefGroup = %s /* Products */;\n\t\t\tprojectDirPath = \"\";\n\t\t\tprojectRoot = \"\";\n" % products_grp
    o += "\t\t\ttargets = (\n\t\t\t\t%s /* %s */,\n\t\t\t);\n\t\t};\n" % (target, m)
    o += "/* End PBXProject section */\n\n"

    o += "/* Begin PBXResourcesBuildPhase section */\n"
    o += build_phase(res_phase, "PBXResourcesBuildPhase", "Resources")
    o += "/* End PBXResourcesBuildPhase section */\n\n"

    o += "/* Begin PBXSourcesBuildPhase section */\n"
    o += build_phase(src_phase, "PBXSourcesBuildPhase", "Sources")
    o += "/* End PBXSourcesBuildPhase section */\n\n"

    o += "/* Begin XCBuildConfiguration section */\n"
    o += config(proj_debug, "Debug", project_settings(True))
    o += config(proj_release, "Release", project_settings(False))
    o += config(tgt_debug, "Debug", target_settings())
    o += config(tgt_release, "Release", target_settings())
    o += "/* End XCBuildConfiguration section */\n\n"

    o += "/* Begin XCConfigurationList section */\n"
    o += config_list(proj_cfg_list, "PBXProject", m, proj_debug, proj_release)
    o += config_list(tgt_cfg_list, "PBXNativeTarget", m, tgt_debug, tgt_release)
    o += "/* End XCConfigurationList section */\n"

    o += "\t};\n\trootObject = %s /* Project object */;\n}\n" % project
    return o


def scheme():
    """Port of XcodeProjectGenerator.scheme(for:)."""
    m = MODULE
    target = oid("forge.%s.target" % m)

    def ref(indent):
        lines = [
            "<BuildableReference",
            '   BuildableIdentifier = "primary"',
            '   BlueprintIdentifier = "%s"' % target,
            '   BuildableName = "%s.app"' % m,
            '   BlueprintName = "%s"' % m,
            '   ReferencedContainer = "container:%s.xcodeproj">' % m,
            "</BuildableReference>",
        ]
        return "\n".join(indent + l for l in lines)

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "1600"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
{ref("           ")}
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES">
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
{ref("           ")}
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
{ref("           ")}
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>"""


WORKSPACE = """<?xml version="1.0" encoding="UTF-8"?>
<Workspace
   version = "1.0">
   <FileRef
      location = "self:">
   </FileRef>
</Workspace>
"""


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    proj = os.path.join(root, MODULE + ".xcodeproj")
    os.makedirs(os.path.join(proj, "project.xcworkspace"), exist_ok=True)
    with open(os.path.join(proj, "project.pbxproj"), "w", encoding="utf-8") as f:
        f.write(pbxproj())
    with open(os.path.join(proj, "project.xcworkspace", "contents.xcworkspacedata"), "w", encoding="utf-8") as f:
        f.write(WORKSPACE)
    schemes = os.path.join(proj, "xcshareddata", "xcschemes")
    os.makedirs(schemes, exist_ok=True)
    with open(os.path.join(schemes, MODULE + ".xcscheme"), "w", encoding="utf-8") as f:
        f.write(scheme())
    print("wrote", proj)


if __name__ == "__main__":
    sys.exit(main())

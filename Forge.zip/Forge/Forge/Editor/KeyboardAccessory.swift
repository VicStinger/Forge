import UIKit

/// The row of code symbols that sits above the keyboard, plus undo / redo /
/// dismiss buttons. Swiping the symbol row scrolls it.
enum KeyboardAccessory {

    private static let symbols: [String] = [
        "{", "}", "(", ")", "[", "]", "<", ">", "\"", ";", ":", ".", ",", "=",
        "$", "_", "\\", "/", "!", "?", "&", "|", "-", "+", "*", "#", "@"
    ]

    static func make(for textView: UITextView) -> UIView {
        let bar = UIInputView(frame: CGRect(x: 0, y: 0, width: 320, height: 44), inputViewStyle: .keyboard)
        bar.allowsSelfSizing = true

        // Scrolling symbol strip
        let strip = UIStackView()
        strip.axis = .horizontal
        strip.spacing = 2
        strip.alignment = .fill
        strip.translatesAutoresizingMaskIntoConstraints = false

        strip.addArrangedSubview(button(systemImage: "arrow.right.to.line", label: "Tab") { [weak textView] in
            textView?.insertText("    ")
        })
        for symbol in symbols {
            strip.addArrangedSubview(button(title: symbol) { [weak textView] in
                textView?.insertText(symbol)
            })
        }

        let scroll = UIScrollView()
        scroll.showsHorizontalScrollIndicator = false
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(strip)
        NSLayoutConstraint.activate([
            strip.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 6),
            strip.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -6),
            strip.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            strip.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            strip.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor),
        ])

        // Fixed trailing controls
        let trailing = UIStackView(arrangedSubviews: [
            button(systemImage: "arrow.uturn.backward", label: "Undo") { [weak textView] in textView?.undoManager?.undo() },
            button(systemImage: "arrow.uturn.forward", label: "Redo") { [weak textView] in textView?.undoManager?.redo() },
            button(systemImage: "keyboard.chevron.compact.down", label: "Hide keyboard") { [weak textView] in textView?.resignFirstResponder() },
        ])
        trailing.axis = .horizontal
        trailing.spacing = 2
        trailing.setContentHuggingPriority(.required, for: .horizontal)
        trailing.setContentCompressionResistancePriority(.required, for: .horizontal)

        let root = UIStackView(arrangedSubviews: [scroll, trailing])
        root.axis = .horizontal
        root.spacing = 4
        root.alignment = .fill
        root.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(root)

        NSLayoutConstraint.activate([
            root.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            root.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -6),
            root.topAnchor.constraint(equalTo: bar.topAnchor),
            root.bottomAnchor.constraint(equalTo: bar.bottomAnchor),
            bar.heightAnchor.constraint(equalToConstant: 44),
        ])
        return bar
    }

    // MARK: Buttons

    private static func button(title: String, action: @escaping () -> Void) -> UIButton {
        var config = UIButton.Configuration.plain()
        config.title = title
        config.baseForegroundColor = .label
        config.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 10, bottom: 8, trailing: 10)
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attrs in
            var out = attrs
            out.font = UIFont.monospacedSystemFont(ofSize: 18, weight: .medium)
            return out
        }
        let b = UIButton(configuration: config, primaryAction: UIAction { _ in action() })
        b.accessibilityLabel = title
        return b
    }

    private static func button(systemImage: String, label: String, action: @escaping () -> Void) -> UIButton {
        var config = UIButton.Configuration.plain()
        config.image = UIImage(systemName: systemImage)
        config.baseForegroundColor = .label
        config.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 10, bottom: 8, trailing: 10)
        let b = UIButton(configuration: config, primaryAction: UIAction { _ in action() })
        b.accessibilityLabel = label
        return b
    }
}

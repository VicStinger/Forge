import SwiftUI
import UIKit

/// SwiftUI wrapper around `CodeUITextView`.
struct CodeEditorView: UIViewRepresentable {

    @Binding var text: String
    /// Set to a UTF-16 offset to move the caret there (e.g. from the Issues list); reset to nil once handled.
    @Binding var jumpTo: Int?
    /// Changes whenever a different file is shown, so undo history and caret reset.
    let documentID: URL
    let fontSize: CGFloat

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> EditorContainer {
        let container = EditorContainer()
        let tv = container.textView
        tv.delegate = context.coordinator
        tv.inputAccessoryView = KeyboardAccessory.make(for: tv)
        context.coordinator.container = container
        context.coordinator.apply(font: fontSize, to: container)
        return container
    }

    func updateUIView(_ container: EditorContainer, context: Context) {
        let c = context.coordinator
        c.parent = self
        let tv = container.textView

        let fontChanged = c.apply(font: fontSize, to: container)

        if c.documentID != documentID {
            c.documentID = documentID
            c.setText(text, in: container, resetUndo: true)
        } else if tv.text != text {
            c.setText(text, in: container, resetUndo: false)
        } else if fontChanged {
            c.rehighlight(container)
        }

        if let offset = jumpTo {
            DispatchQueue.main.async {
                let length = (tv.text as NSString).length
                tv.selectedRange = NSRange(location: min(max(offset, 0), length), length: 0)
                tv.scrollRangeToVisible(tv.selectedRange)
                tv.becomeFirstResponder()
                self.jumpTo = nil
            }
        }
    }

    // MARK: Coordinator

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: CodeEditorView
        weak var container: EditorContainer?
        var documentID: URL?

        private var font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        private var didApplyFont = false
        private var isApplyingExternalChange = false
        private var isInserting = false

        private let indentUnit = "    "
        private let pairs: [String: String] = ["(": ")", "[": "]", "{": "}", "\"": "\""]

        init(parent: CodeEditorView) { self.parent = parent }

        // MARK: Font / text

        /// Returns true if the font actually changed.
        @discardableResult
        func apply(font size: CGFloat, to container: EditorContainer) -> Bool {
            guard !didApplyFont || abs(font.pointSize - size) > 0.01 else { return false }
            didApplyFont = true
            font = UIFont.monospacedSystemFont(ofSize: size, weight: .regular)
            container.textView.font = font
            container.gutter.font = UIFont.monospacedDigitSystemFont(ofSize: max(size - 3, 9), weight: .regular)
            return true
        }

        func setText(_ string: String, in container: EditorContainer, resetUndo: Bool) {
            let tv = container.textView
            let previous = tv.selectedRange
            isApplyingExternalChange = true
            tv.text = string
            SwiftHighlighter.apply(to: tv.textStorage, font: font)
            tv.typingAttributes = SwiftHighlighter.baseAttributes(font: font)
            tv.refreshLineIndex()
            if resetUndo {
                tv.undoManager?.removeAllActions()
                tv.selectedRange = NSRange(location: 0, length: 0)
                tv.setContentOffset(.zero, animated: false)
            } else {
                let length = (string as NSString).length
                tv.selectedRange = NSRange(location: min(previous.location, length), length: 0)
            }
            container.gutter.setNeedsDisplay()
            isApplyingExternalChange = false
        }

        func rehighlight(_ container: EditorContainer) {
            let tv = container.textView
            SwiftHighlighter.apply(to: tv.textStorage, font: font)
            tv.typingAttributes = SwiftHighlighter.baseAttributes(font: font)
            container.gutter.setNeedsDisplay()
        }

        // MARK: UITextViewDelegate

        func textViewDidChange(_ textView: UITextView) {
            guard let tv = textView as? CodeUITextView, !isApplyingExternalChange else { return }
            tv.refreshLineIndex()
            // Don't restyle while an input method is composing text.
            if tv.markedTextRange == nil {
                SwiftHighlighter.apply(to: tv.textStorage, font: font)
                tv.typingAttributes = SwiftHighlighter.baseAttributes(font: font)
            }
            container?.gutter.setNeedsDisplay()
            if parent.text != tv.text { parent.text = tv.text }
        }

        func textView(_ textView: UITextView,
                      shouldChangeTextIn range: NSRange,
                      replacementText replacement: String) -> Bool {
            guard !isInserting, !isApplyingExternalChange else { return true }
            let ns = textView.text as NSString

            // Hardware Tab key -> spaces
            if replacement == "\t" {
                insert(indentUnit, replacing: range, in: textView)
                return false
            }

            // Return: carry indentation, open a block when after an opener
            if replacement == "\n" {
                let lineStart = ns.lineRange(for: NSRange(location: range.location, length: 0)).location
                let before = ns.substring(with: NSRange(location: lineStart, length: range.location - lineStart))
                let indent = String(before.prefix { $0 == " " || $0 == "\t" })
                let trimmed = before.trimmingCharacters(in: .whitespaces)
                let next = character(in: ns, at: range.location + range.length)

                var insertion = "\n" + indent
                var caretBack = 0
                if let last = trimmed.last, "{([".contains(last) {
                    insertion += indentUnit
                    let closer: Character = last == "{" ? "}" : (last == "(" ? ")" : "]")
                    if next == closer {
                        insertion += "\n" + indent
                        caretBack = (indent as NSString).length + 1
                    }
                }
                insert(insertion, replacing: range, in: textView, caretBackBy: caretBack)
                return false
            }

            // Backspace between an empty pair, e.g. {|}
            if replacement.isEmpty, range.length == 1, range.location + 1 < ns.length,
               let open = character(in: ns, at: range.location),
               let close = character(in: ns, at: range.location + 1),
               pairs[String(open)] == String(close) {
                insert("", replacing: NSRange(location: range.location, length: 2), in: textView)
                return false
            }

            guard replacement.count == 1 else { return true }

            // Typing a closer when the next character already is that closer: step over it.
            if range.length == 0, [")", "]", "}", "\""].contains(replacement),
               let next = character(in: ns, at: range.location), String(next) == replacement {
                textView.selectedRange = NSRange(location: range.location + 1, length: 0)
                return false
            }

            // Typing "}" on a whitespace-only line: dedent one level.
            if replacement == "}", range.length == 0 {
                let lineStart = ns.lineRange(for: NSRange(location: range.location, length: 0)).location
                let before = ns.substring(with: NSRange(location: lineStart, length: range.location - lineStart))
                if before.count >= indentUnit.count, before.allSatisfy({ $0 == " " }) {
                    let dedent = NSRange(location: range.location - indentUnit.count, length: indentUnit.count)
                    insert("}", replacing: dedent, in: textView)
                    return false
                }
            }

            // Auto-pair openers (wrapping any selection).
            if let close = pairs[replacement] {
                if replacement == "\"" {
                    // Don't pair when finishing a word or after an escape.
                    if let prev = character(in: ns, at: range.location - 1),
                       prev.isLetter || prev.isNumber || prev == "\\" { return true }
                }
                if range.length == 0, let next = character(in: ns, at: range.location),
                   next.isLetter || next.isNumber { return true }

                let selected = ns.substring(with: range)
                insert(replacement + selected + close, replacing: range, in: textView,
                       caretBackBy: range.length == 0 ? 1 : 0)
                return false
            }
            return true
        }

        // MARK: Helpers

        private func character(in ns: NSString, at index: Int) -> Character? {
            guard index >= 0, index < ns.length else { return nil }
            return Character(UnicodeScalar(ns.character(at: index)) ?? " ")
        }

        private func insert(_ string: String, replacing range: NSRange,
                            in textView: UITextView, caretBackBy back: Int = 0) {
            guard let start = textView.position(from: textView.beginningOfDocument, offset: range.location),
                  let end = textView.position(from: start, offset: range.length),
                  let textRange = textView.textRange(from: start, to: end) else { return }

            isInserting = true
            textView.replace(textRange, withText: string)
            isInserting = false

            let caret = range.location + (string as NSString).length - back
            textView.selectedRange = NSRange(location: max(caret, 0), length: 0)
            textViewDidChange(textView)
        }
    }
}

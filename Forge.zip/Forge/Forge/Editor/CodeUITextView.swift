import UIKit

/// A TextKit 1 text view configured for code: no autocorrect, no smart
/// punctuation, and a fixed left inset that leaves room for the line-number gutter.
final class CodeUITextView: UITextView {

    static let gutterWidth: CGFloat = 46

    /// UTF-16 offsets at which each line starts (always contains 0).
    private(set) var lineStarts: [Int] = [0]

    // The text view only retains its container, and a container holds its layout
    // manager weakly, so we keep the rest of the hand-built TextKit 1 stack alive here.
    private let retainedStorage: NSTextStorage
    private let retainedLayoutManager: NSLayoutManager

    init() {
        // Build the TextKit 1 stack by hand so line-fragment APIs stay available.
        let storage = NSTextStorage()
        let layout = NSLayoutManager()
        let container = NSTextContainer(size: CGSize(width: CGFloat(0), height: CGFloat.greatestFiniteMagnitude))
        container.widthTracksTextView = true
        container.lineFragmentPadding = 0
        layout.addTextContainer(container)
        storage.addLayoutManager(layout)
        retainedStorage = storage
        retainedLayoutManager = layout
        super.init(frame: .zero, textContainer: container)

        autocorrectionType = .no
        autocapitalizationType = .none
        spellCheckingType = .no
        smartQuotesType = .no
        smartDashesType = .no
        smartInsertDeleteType = .no
        keyboardDismissMode = .interactive
        alwaysBounceVertical = true
        isFindInteractionEnabled = true
        backgroundColor = SyntaxTheme.background
        textContainerInset = UIEdgeInsets(top: 12, left: Self.gutterWidth + 8, bottom: 80, right: 8)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    /// Keep the gutter in step with scrolling and reflow (rotation, resizing).
    override func layoutSubviews() {
        super.layoutSubviews()
        (superview as? EditorContainer)?.gutter.setNeedsDisplay()
    }

    /// Recompute the line index. Call after any text change.
    func refreshLineIndex() {
        var starts = [0]
        var offset = 0
        for unit in textStorage.string.utf16 {
            offset += 1
            if unit == 10 { starts.append(offset) }
        }
        lineStarts = starts
    }

    /// 1-based line number containing the given UTF-16 offset.
    func lineNumber(forCharacterIndex index: Int) -> Int {
        var lo = 0, hi = lineStarts.count - 1
        while lo < hi {
            let mid = (lo + hi + 1) / 2
            if lineStarts[mid] <= index { lo = mid } else { hi = mid - 1 }
        }
        return lo + 1
    }
}

/// Draws line numbers for the visible part of a `CodeUITextView`.
/// It sits *over* the text view (not inside its scroll content) so it never
/// has to be taller than the screen.
final class GutterView: UIView {

    weak var textView: CodeUITextView?
    var font = UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .regular)

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = SyntaxTheme.gutterBackground
        isUserInteractionEnabled = false
        contentMode = .redraw
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func draw(_ rect: CGRect) {
        guard let tv = textView else { return }
        let layoutManager = tv.layoutManager
        let container = tv.textContainer
        let inset = tv.textContainerInset
        let offsetY = tv.contentOffset.y
        let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: SyntaxTheme.gutterText]
        let text = tv.textStorage.string as NSString

        func drawNumber(_ n: Int, lineRect: CGRect) {
            let label = "\(n)" as NSString
            let size = label.size(withAttributes: attrs)
            let y = lineRect.minY + inset.top - offsetY + (lineRect.height - size.height) / 2
            label.draw(at: CGPoint(x: bounds.width - size.width - 8, y: y), withAttributes: attrs)
        }

        if text.length > 0 {
            let visible = CGRect(x: 0, y: offsetY - inset.top,
                                 width: container.size.width, height: bounds.height)
            let glyphRange = layoutManager.glyphRange(forBoundingRect: visible, in: container)

            layoutManager.enumerateLineFragments(forGlyphRange: glyphRange) { lineRect, _, _, lineGlyphs, _ in
                let chars = layoutManager.characterRange(forGlyphRange: lineGlyphs, actualGlyphRange: nil)
                // Only the first fragment of a wrapped paragraph gets a number.
                let startsParagraph = chars.location == 0 || text.character(at: chars.location - 1) == 10
                if startsParagraph {
                    drawNumber(tv.lineNumber(forCharacterIndex: chars.location), lineRect: lineRect)
                }
            }
        }

        // The empty line after a trailing newline (or the only line of an empty file).
        let extra = layoutManager.extraLineFragmentRect
        if extra.height > 0 {
            drawNumber(tv.lineStarts.count, lineRect: extra)
        }

        // Hairline separator on the trailing edge.
        UIColor.separator.setFill()
        UIRectFill(CGRect(x: bounds.width - 0.5, y: 0, width: 0.5, height: bounds.height))
    }
}

/// Hosts the text view and its gutter side by side.
final class EditorContainer: UIView {

    let textView = CodeUITextView()
    let gutter = GutterView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        gutter.textView = textView
        addSubview(textView)
        addSubview(gutter)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        textView.frame = bounds
        gutter.frame = CGRect(x: 0, y: 0, width: CodeUITextView.gutterWidth, height: bounds.height)
    }
}

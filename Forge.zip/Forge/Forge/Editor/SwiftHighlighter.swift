import UIKit

/// Applies syntax colours to an `NSTextStorage` in place.
enum SwiftHighlighter {

    static func apply(to storage: NSTextStorage, font: UIFont) {
        let full = NSRange(location: 0, length: storage.length)
        let tokens = SwiftLexer.tokenize(storage.string)

        storage.beginEditing()
        storage.setAttributes([.font: font, .foregroundColor: SyntaxTheme.text], range: full)
        for token in tokens {
            guard let color = SyntaxTheme.color(for: token.kind) else { continue }
            let range = NSIntersectionRange(token.range, full)
            if range.length > 0 {
                storage.addAttribute(.foregroundColor, value: color, range: range)
            }
        }
        storage.endEditing()
    }

    static func baseAttributes(font: UIFont) -> [NSAttributedString.Key: Any] {
        [.font: font, .foregroundColor: SyntaxTheme.text]
    }
}

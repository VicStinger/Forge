import UIKit

/// Colours for the code editor. Every colour adapts to light / dark mode.
enum SyntaxTheme {

    static let text = UIColor.label
    static let gutterText = UIColor.tertiaryLabel
    static let gutterBackground = UIColor.secondarySystemBackground
    static let background = UIColor.systemBackground

    static func color(for kind: SwiftLexer.Kind) -> UIColor? {
        switch kind {
        case .comment:   return comment
        case .string:    return string
        case .number:    return number
        case .keyword:   return keyword
        case .type:      return type
        case .attribute: return attribute
        case .directive: return attribute
        case .bracket:   return nil
        }
    }

    private static let comment   = UIColor(light: 0x5D6C79, dark: 0x7F8C98)
    private static let string    = UIColor(light: 0xD12F1B, dark: 0xFF8170)
    private static let number    = UIColor(light: 0x272AD8, dark: 0xD9C97C)
    private static let keyword   = UIColor(light: 0xAD3DA4, dark: 0xFF7AB2)
    private static let type      = UIColor(light: 0x0B4F79, dark: 0x6BDFFF)
    private static let attribute = UIColor(light: 0x78492A, dark: 0xFFA14F)
}

extension UIColor {
    convenience init(light: UInt32, dark: UInt32) {
        self.init { traits in
            let hex = traits.userInterfaceStyle == .dark ? dark : light
            return UIColor(
                red: CGFloat((hex >> 16) & 0xFF) / 255,
                green: CGFloat((hex >> 8) & 0xFF) / 255,
                blue: CGFloat(hex & 0xFF) / 255,
                alpha: 1
            )
        }
    }
}

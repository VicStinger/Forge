import Foundation

/// A small, forgiving lexer for Swift used for syntax highlighting and
/// bracket checking. It is not a parser: it only needs to classify text
/// well enough to colour it and to ignore brackets inside strings/comments.
struct SwiftLexer {

    enum Kind {
        case comment, string, number, keyword, type, attribute, directive, bracket
    }

    struct Token {
        let kind: Kind
        /// UTF-16 range, directly usable with NSRange / NSTextStorage.
        let range: NSRange
        /// False for an unterminated string or block comment.
        let isTerminated: Bool
    }

    static let keywords: Set<String> = [
        "associatedtype", "class", "deinit", "enum", "extension", "fileprivate", "func", "import",
        "init", "inout", "internal", "let", "open", "operator", "private", "precedencegroup",
        "protocol", "public", "rethrows", "static", "struct", "subscript", "typealias", "var",
        "break", "case", "catch", "continue", "default", "defer", "do", "else", "fallthrough",
        "for", "guard", "if", "in", "repeat", "return", "throw", "switch", "where", "while",
        "as", "await", "async", "any", "some", "is", "nil", "self", "Self", "super", "throws",
        "true", "false", "try", "final", "override", "lazy", "weak", "unowned", "mutating",
        "nonmutating", "convenience", "required", "indirect", "actor", "nonisolated", "get",
        "set", "willSet", "didSet", "isolated", "consuming", "borrowing"
    ]

    static func tokenize(_ text: String) -> [Token] {
        let u = Array(text.utf16)
        let n = u.count
        var tokens: [Token] = []
        var i = 0

        @inline(__always) func at(_ k: Int) -> UInt16 { k < n ? u[k] : 0 }
        func isIdentStart(_ c: UInt16) -> Bool {
            (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 95 || c > 127
        }
        func isDigit(_ c: UInt16) -> Bool { c >= 48 && c <= 57 }
        func isIdentPart(_ c: UInt16) -> Bool { isIdentStart(c) || isDigit(c) }

        let slash: UInt16 = 47, star: UInt16 = 42, quote: UInt16 = 34
        let backslash: UInt16 = 92, newline: UInt16 = 10, hash: UInt16 = 35, at_: UInt16 = 64

        /// Skip a backslash escape inside a string. For `\( ... )` interpolation,
        /// skip to the matching paren, tolerating nested string literals.
        func skipEscape(_ k: Int) -> Int {
            guard at(k + 1) == 40 else { return k + 2 }
            var j = k + 2
            var depth = 1
            while j < n && depth > 0 {
                let ch = u[j]
                if ch == quote {
                    j += 1
                    while j < n && u[j] != quote && u[j] != newline {
                        if u[j] == backslash { j += 1 }
                        j += 1
                    }
                    j += 1
                    continue
                }
                if ch == 40 { depth += 1 } else if ch == 41 { depth -= 1 }
                j += 1
            }
            return j
        }

        while i < n {
            let c = u[i]

            // Line comment
            if c == slash && at(i + 1) == slash {
                let start = i
                while i < n && u[i] != newline { i += 1 }
                tokens.append(Token(kind: .comment, range: NSRange(location: start, length: i - start), isTerminated: true))
                continue
            }

            // Block comment (nested)
            if c == slash && at(i + 1) == star {
                let start = i
                var depth = 1
                i += 2
                while i < n && depth > 0 {
                    if u[i] == slash && at(i + 1) == star { depth += 1; i += 2 }
                    else if u[i] == star && at(i + 1) == slash { depth -= 1; i += 2 }
                    else { i += 1 }
                }
                tokens.append(Token(kind: .comment, range: NSRange(location: start, length: i - start), isTerminated: depth == 0))
                continue
            }

            // Strings: multi-line """ ... """ and single-line "..."
            if c == quote {
                let start = i
                if at(i + 1) == quote && at(i + 2) == quote {
                    i += 3
                    var closed = false
                    while i < n {
                        if u[i] == backslash { i = skipEscape(i); continue }
                        if u[i] == quote && at(i + 1) == quote && at(i + 2) == quote { i += 3; closed = true; break }
                        i += 1
                    }
                    i = min(i, n)
                    tokens.append(Token(kind: .string, range: NSRange(location: start, length: i - start), isTerminated: closed))
                } else {
                    i += 1
                    var closed = false
                    while i < n {
                        if u[i] == backslash { i = skipEscape(i); continue }
                        if u[i] == quote { i += 1; closed = true; break }
                        if u[i] == newline { break }
                        i += 1
                    }
                    i = min(i, n)
                    tokens.append(Token(kind: .string, range: NSRange(location: start, length: i - start), isTerminated: closed))
                }
                continue
            }

            // Numbers
            if isDigit(c) {
                let start = i
                i += 1
                while i < n && (isIdentPart(u[i]) || (u[i] == 46 && isDigit(at(i + 1)))) { i += 1 }
                tokens.append(Token(kind: .number, range: NSRange(location: start, length: i - start), isTerminated: true))
                continue
            }

            // @Attribute  /  #directive
            if (c == at_ || c == hash) && isIdentStart(at(i + 1)) {
                let start = i
                i += 1
                while i < n && isIdentPart(u[i]) { i += 1 }
                tokens.append(Token(kind: c == at_ ? .attribute : .directive,
                                    range: NSRange(location: start, length: i - start), isTerminated: true))
                continue
            }

            // Identifiers / keywords / types
            if isIdentStart(c) {
                let start = i
                i += 1
                while i < n && isIdentPart(u[i]) { i += 1 }
                let range = NSRange(location: start, length: i - start)
                let word = String(decoding: u[start..<i], as: UTF16.self)
                if keywords.contains(word) {
                    tokens.append(Token(kind: .keyword, range: range, isTerminated: true))
                } else if c >= 65 && c <= 90 {
                    tokens.append(Token(kind: .type, range: range, isTerminated: true))
                }
                continue
            }

            // Brackets
            if c == 40 || c == 41 || c == 91 || c == 93 || c == 123 || c == 125 {
                tokens.append(Token(kind: .bracket, range: NSRange(location: i, length: 1), isTerminated: true))
            }
            i += 1
        }
        return tokens
    }
}

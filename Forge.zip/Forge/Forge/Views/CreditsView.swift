import SwiftUI

/// Who made Forge.
struct CreditsView: View {
    @Environment(\.dismiss) private var dismiss

    private var versionText: String {
        let info = Bundle.main.infoDictionary
        let version = info?["CFBundleShortVersionString"] as? String ?? "1.0"
        let build = info?["CFBundleVersion"] as? String ?? "1"
        return "Version \(version) (\(build))"
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(spacing: 10) {
                        Image(systemName: "hammer.fill")
                            .font(.system(size: 40, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 84, height: 84)
                            .background(Color.accentColor.gradient, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                            .accessibilityHidden(true)
                        Text("Forge")
                            .font(.title.bold())
                        Text("Write SwiftUI apps on your iPhone or iPad, then export them as Xcode projects or build an IPA in the cloud.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                        Text(versionText)
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .listRowBackground(Color.clear)
                }

                Section("Credits") {
                    creditRow(name: "VicStinger",
                              role: "Idea & Backend Developer",
                              symbol: "lightbulb.fill",
                              tint: .yellow)
                    creditRow(name: "Claude",
                              role: "Main Developer",
                              detail: "An AI model made by Anthropic",
                              symbol: "chevron.left.forwardslash.chevron.right",
                              tint: .orange)
                }

                Section {
                    Text("Forge is an independent project. It isn't affiliated with or endorsed by Apple Inc. Xcode, iOS, iPhone and iPad are trademarks of Apple Inc. Cloud builds run on GitHub Actions; GitHub is a trademark of GitHub, Inc.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Credits")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func creditRow(name: String, role: String, detail: String? = nil,
                           symbol: String, tint: Color) -> some View {
        HStack(spacing: 14) {
            Image(systemName: symbol)
                .font(.title3)
                .foregroundStyle(tint)
                .frame(width: 36, height: 36)
                .background(tint.opacity(0.15), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(.headline)
                Text(role).font(.subheadline).foregroundStyle(.secondary)
                if let detail {
                    Text(detail).font(.caption).foregroundStyle(.tertiary)
                }
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }
}

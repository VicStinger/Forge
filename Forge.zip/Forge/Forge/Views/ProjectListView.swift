import SwiftUI
import UniformTypeIdentifiers

struct ProjectListView: View {
    @Environment(ProjectStore.self) private var store
    @State private var path: [ProjectRef] = []
    @State private var showingNewProject = false
    @State private var showingImporter = false
    @State private var showingCredits = false
    @State private var isImporting = false
    @State private var errorMessage: String?
    @State private var notice: String?

    var body: some View {
        NavigationStack(path: $path) {
            Group {
                if store.projects.isEmpty {
                    emptyState
                } else {
                    projectList
                }
            }
            .navigationTitle("Forge")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showingCredits = true
                    } label: {
                        Label("Credits", systemImage: "info.circle")
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Menu {
                        Button {
                            showingNewProject = true
                        } label: {
                            Label("New Project", systemImage: "plus")
                        }
                        Button {
                            showingImporter = true
                        } label: {
                            Label("Import Folder or Zip…", systemImage: "square.and.arrow.down")
                        }
                    } label: {
                        Label("Add", systemImage: "plus")
                    }
                }
            }
            .navigationDestination(for: ProjectRef.self) { project in
                ProjectWorkspaceView(project: project, store: store)
            }
            .sheet(isPresented: $showingNewProject) {
                NewProjectSheet { created in
                    // Wait for the sheet to dismiss before pushing.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                        path.append(created)
                    }
                }
            }
            .sheet(isPresented: $showingCredits) { CreditsView() }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [.zip, .folder]) { result in
                handleImport(result)
            }
            .overlay { if isImporting { importingOverlay } }
            .alert("Something went wrong",
                   isPresented: Binding(get: { errorMessage != nil },
                                        set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "")
            }
            .alert("Imported",
                   isPresented: Binding(get: { notice != nil },
                                        set: { if !$0 { notice = nil } })) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(notice ?? "")
            }
        }
    }

    // MARK: Pieces

    private var emptyState: some View {
        ContentUnavailableView {
            Label("No Projects Yet", systemImage: "hammer")
        } description: {
            Text("Write SwiftUI apps right here, or import an existing Xcode project. Export them as Xcode projects or build an IPA in the cloud.")
        } actions: {
            Button("New Project") { showingNewProject = true }
                .buttonStyle(.borderedProminent)
            Button("Import Folder or Zip…") { showingImporter = true }
        }
    }

    private var projectList: some View {
        List {
            ForEach(store.projects) { project in
                NavigationLink(value: project) {
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 8) {
                            Text(project.manifest.name)
                                .font(.headline)
                            if project.manifest.isImported {
                                Text("Imported")
                                    .font(.caption2.weight(.semibold))
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.accentColor.opacity(0.15), in: Capsule())
                                    .foregroundStyle(.tint)
                            }
                        }
                        Text(project.manifest.bundleID)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(project.manifest.createdAt, style: .date)
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 2)
                }
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) {
                        perform { try store.delete(project) }
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
                .contextMenu {
                    Button {
                        perform { try store.duplicate(project) }
                    } label: {
                        Label("Duplicate", systemImage: "plus.square.on.square")
                    }
                    Button(role: .destructive) {
                        perform { try store.delete(project) }
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
        }
    }

    private var importingOverlay: some View {
        ZStack {
            Color.black.opacity(0.25).ignoresSafeArea()
            VStack(spacing: 12) {
                ProgressView()
                Text("Importing…").font(.subheadline)
            }
            .padding(24)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .transition(.opacity)
    }

    // MARK: Actions

    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .failure(let error):
            // Dismissing the picker isn't an error.
            if (error as? CocoaError)?.code != .userCancelled {
                errorMessage = error.localizedDescription
            }
        case .success(let url):
            isImporting = true
            Task {
                do {
                    // Copying / unzipping can take a while, so keep it off the main thread.
                    let staged = try await Task.detached(priority: .userInitiated) {
                        try ProjectImporter.stage(from: url)
                    }.value
                    let project = try store.adopt(staged)
                    isImporting = false
                    if let note = staged.note { notice = note }
                    path.append(project)
                } catch {
                    isImporting = false
                    errorMessage = error.localizedDescription
                }
            }
        }
    }

    private func perform<T>(_ work: () throws -> T) {
        do { _ = try work() } catch { errorMessage = error.localizedDescription }
    }
}

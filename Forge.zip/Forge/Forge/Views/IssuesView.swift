import SwiftUI

/// Lists structural problems found by `SwiftLinter`. Tapping one jumps the caret to it.
struct IssuesView: View {
    let issues: [LintIssue]
    let fileName: String
    let onSelect: (LintIssue) -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if issues.isEmpty {
                    ContentUnavailableView(
                        "No Structural Issues",
                        systemImage: "checkmark.circle",
                        description: Text("Brackets are balanced and strings are closed. This is not a compiler check. Xcode will find type errors when you build.")
                    )
                } else {
                    List(issues) { issue in
                        Button {
                            onSelect(issue)
                            dismiss()
                        } label: {
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: issue.severity == .error
                                      ? "xmark.octagon.fill" : "exclamationmark.triangle.fill")
                                    .foregroundStyle(issue.severity == .error ? .red : .yellow)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(issue.message).foregroundStyle(.primary)
                                    Text("\(fileName) · line \(issue.line), column \(issue.column)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Issues")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

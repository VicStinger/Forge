import SwiftUI

/// Edits the values that end up in the exported Xcode project.
/// Imported projects keep their own project file, so they get different fields.
struct ProjectSettingsView: View {
    let manifest: ProjectManifest
    let onSave: (ProjectManifest) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var draft: ProjectManifest

    private static let targets = ["16.0", "17.0", "17.4", "18.0", "26.0"]

    init(manifest: ProjectManifest, onSave: @escaping (ProjectManifest) -> Void) {
        self.manifest = manifest
        self.onSave = onSave
        _draft = State(initialValue: manifest)
    }

    var body: some View {
        NavigationStack {
            Form {
                if draft.isImported {
                    importedSections
                } else {
                    generatedSections
                }
            }
            .navigationTitle("Project Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        onSave(draft)
                        dismiss()
                    }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    // MARK: Forge-generated projects

    @ViewBuilder
    private var generatedSections: some View {
        Section("App") {
            LabeledContent("Display Name") {
                TextField("Name", text: $draft.name)
                    .multilineTextAlignment(.trailing)
            }
            LabeledContent("Bundle ID") {
                TextField("com.example.app", text: $draft.bundleID)
                    .multilineTextAlignment(.trailing)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            LabeledContent("Version") {
                TextField("1.0", text: $draft.version)
                    .multilineTextAlignment(.trailing)
                    .keyboardType(.numbersAndPunctuation)
            }
        }

        Section {
            Picker("iOS Deployment Target", selection: $draft.deploymentTarget) {
                ForEach(Self.targets, id: \.self) { Text($0).tag($0) }
            }
        } footer: {
            Text("Xcode target name: \(draft.moduleName). The template code uses @Observable, so keep this at 17.0 or higher.")
        }
    }

    // MARK: Imported projects

    @ViewBuilder
    private var importedSections: some View {
        Section {
            LabeledContent("Name") {
                TextField("Name", text: $draft.name)
                    .multilineTextAlignment(.trailing)
            }
        } footer: {
            Text("Used for the project list and the name of the exported folder or zip. It doesn't rename anything inside the Xcode project.")
        }

        Section {
            LabeledContent("Project path") {
                TextField("MyApp.xcodeproj", text: Binding(
                    get: { draft.buildContainer ?? "" },
                    set: { draft.buildContainer = $0 }))
                    .multilineTextAlignment(.trailing)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            LabeledContent("Scheme") {
                TextField("Automatic", text: Binding(
                    get: { draft.scheme ?? "" },
                    set: { draft.scheme = $0 }))
                    .multilineTextAlignment(.trailing)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
        } header: {
            Text("Cloud Build")
        } footer: {
            Text("This is an imported Xcode project, so its bundle ID, version and deployment target live in the project itself and Forge never rewrites them. The project path is relative to the project's top folder. Leave the scheme empty to use the first one the project lists.")
        }

        Section("Detected") {
            LabeledContent("Bundle ID", value: draft.bundleID)
            LabeledContent("Deployment Target", value: "iOS \(draft.deploymentTarget)")
        }
        .foregroundStyle(.secondary)
    }
}

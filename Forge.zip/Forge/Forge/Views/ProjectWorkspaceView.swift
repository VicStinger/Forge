import SwiftUI

/// The IDE screen: file navigator + code editor + export.
/// iPad / large widths show the navigator beside the editor; iPhone shows it in a sheet.
struct ProjectWorkspaceView: View {
    @State private var session: ProjectSession
    @State private var selection: URL?
    @State private var prompt: FilePrompt?
    @State private var promptText = ""
    @State private var showingSettings = false
    @State private var showingIssues = false
    @State private var showingFilesSheet = false
    @State private var showSidebar = true
    @State private var shareItem: ShareItem?
    @State private var folderExport: ShareItem?
    @State private var jumpTo: Int?
    @State private var build: BuildService
    @State private var showingBuild = false

    @AppStorage("editorFontSize") private var fontSize = 14.0
    @Environment(\.horizontalSizeClass) private var sizeClass
    @Environment(\.scenePhase) private var scenePhase

    @MainActor
    init(project: ProjectRef, store: ProjectStore) {
        _session = State(initialValue: ProjectSession(project: project, store: store))
        _build = State(initialValue: BuildService())
    }

    private var isRegular: Bool { sizeClass == .regular }

    var body: some View {
        HStack(spacing: 0) {
            if isRegular && showSidebar {
                sidebar
                    .frame(width: 280)
                Divider()
            }
            editor
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .sheet(isPresented: $showingFilesSheet) { filesSheet }
        .sheet(isPresented: $showingSettings) {
            ProjectSettingsView(manifest: session.project.manifest) { session.updateManifest($0) }
        }
        .sheet(isPresented: $showingIssues) {
            IssuesView(issues: session.issues,
                       fileName: session.selectedFile?.lastPathComponent ?? "") { issue in
                jumpTo = issue.location
            }
        }
        .sheet(item: $shareItem) { item in
            ShareSheet(url: item.url)
        }
        .sheet(item: $folderExport) { item in
            FilesExportPicker(url: item.url)
        }
        .sheet(isPresented: $showingBuild) {
            BuildIPAView(service: build,
                         manifest: session.project.manifest,
                         sourcesDirectory: session.sourcesDirectory) { diagnostic in
                jump(to: diagnostic)
            }
        }
        .alert(prompt?.title ?? "", isPresented: promptIsPresented, presenting: prompt) { p in
            TextField("Name", text: $promptText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Cancel", role: .cancel) {}
            Button(p.confirmTitle) { commit(p) }
        } message: { p in
            Text(p.message)
        }
        .alert("Something went wrong", isPresented: errorIsPresented) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(session.lastError ?? "")
        }
        .onChange(of: prompt?.id) { _, _ in promptText = prompt?.initialText ?? "" }
        .onChange(of: selection) { _, new in
            guard let new, new != session.selectedFile,
                  let node = session.node(for: new), !node.isDirectory else { return }
            session.open(new)
            showingFilesSheet = false
        }
        .onChange(of: session.selectedFile) { _, new in
            if let new { selection = new }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { session.flushSave() }
        }
        .onDisappear { session.flushSave() }
    }

    // MARK: Editor area

    @ViewBuilder
    private var editor: some View {
        if let file = session.selectedFile {
            if session.isBinary {
                ContentUnavailableView(
                    "Can't Edit This File",
                    systemImage: "photo",
                    description: Text("Only text files can be edited here. “\(file.lastPathComponent)” is still included when you export.")
                )
            } else {
                CodeEditorView(
                    text: Binding(get: { session.text }, set: { session.setText($0) }),
                    jumpTo: $jumpTo,
                    documentID: file,
                    fontSize: fontSize
                )
            }
        } else {
            ContentUnavailableView(
                "No File Selected",
                systemImage: "doc.text",
                description: Text("Pick a file from the navigator, or create a new one.")
            )
        }
    }

    // MARK: Navigator

    private var sidebar: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Files").font(.headline)
                Spacer()
                Menu { newItemButtons } label: {
                    Image(systemName: "plus.circle").imageScale(.large)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            Divider()
            FileTreeView(session: session, selection: $selection, prompt: $prompt)
        }
        .background(Color(uiColor: .secondarySystemBackground))
    }

    private var filesSheet: some View {
        NavigationStack {
            FileTreeView(session: session, selection: $selection, prompt: $prompt)
                .navigationTitle(session.project.manifest.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Done") { showingFilesSheet = false }
                    }
                    ToolbarItem(placement: .primaryAction) {
                        Menu { newItemButtons } label: { Image(systemName: "plus") }
                    }
                }
        }
        .presentationDetents([.medium, .large])
    }

    @ViewBuilder
    private var newItemButtons: some View {
        Button {
            prompt = .newFile(folder: session.targetFolder(for: selection))
        } label: {
            Label("New File", systemImage: "doc.badge.plus")
        }
        Button {
            prompt = .newFolder(folder: session.targetFolder(for: selection))
        } label: {
            Label("New Folder", systemImage: "folder.badge.plus")
        }
    }

    // MARK: Toolbar

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button {
                if isRegular { withAnimation { showSidebar.toggle() } }
                else { showingFilesSheet = true }
            } label: {
                Label("Files", systemImage: "sidebar.left")
            }
        }

        ToolbarItem(placement: .principal) {
            VStack(spacing: 0) {
                Text(session.project.manifest.name).font(.headline)
                if let file = session.selectedFile {
                    Text(file.lastPathComponent + (session.hasUnsavedChanges ? " •" : ""))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }

        ToolbarItemGroup(placement: .navigationBarTrailing) {
            if session.selectedFile?.pathExtension == "swift" {
                Button { showingIssues = true } label: {
                    if session.issues.isEmpty {
                        Label("No issues", systemImage: "checkmark.circle")
                    } else {
                        Label("\(session.issues.count) issues", systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                    }
                }
            }

            Menu {
                Button { showingBuild = true } label: {
                    Label("Build IPA…", systemImage: "hammer.fill")
                }
                Button(action: export) {
                    Label("Export Xcode Project (.zip)", systemImage: "square.and.arrow.up")
                }
                Button(action: exportFolder) {
                    Label("Save Xcode Project Folder to Files…", systemImage: "folder.badge.plus")
                }
            } label: {
                if build.isBusy {
                    ProgressView()
                } else {
                    Label("Build & Export", systemImage: "hammer")
                }
            }

            Menu {
                Button { showingSettings = true } label: {
                    Label("Project Settings", systemImage: "gearshape")
                }
                Divider()
                Button { fontSize = min(fontSize + 1, 28) } label: {
                    Label("Larger Text", systemImage: "textformat.size.larger")
                }
                Button { fontSize = max(fontSize - 1, 10) } label: {
                    Label("Smaller Text", systemImage: "textformat.size.smaller")
                }
            } label: {
                Label("More", systemImage: "ellipsis.circle")
            }
        }
    }

    // MARK: Actions

    private func commit(_ p: FilePrompt) {
        switch p {
        case .newFile(let folder): session.createFile(named: promptText, in: folder)
        case .newFolder(let folder): session.createFolder(named: promptText, in: folder)
        case .rename(let url, _): session.rename(url, to: promptText)
        }
    }

    /// Open the file a compiler message points at and put the caret on that line.
    private func jump(to diagnostic: BuildDiagnostic) {
        guard let path = diagnostic.path else { return }
        let url = session.sourcesDirectory.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else { return }
        session.open(url)
        jumpTo = session.utf16Offset(line: diagnostic.line, column: diagnostic.column)
    }

    private func exportFolder() {
        do {
            session.flushSave()
            folderExport = ShareItem(url: try ProjectExporter.exportFolder(
                manifest: session.project.manifest,
                sourcesDir: session.sourcesDirectory))
        } catch {
            session.lastError = error.localizedDescription
        }
    }

    private func export() {
        do {
            shareItem = ShareItem(url: try session.exportXcodeProject())
        } catch {
            session.lastError = error.localizedDescription
        }
    }

    private var promptIsPresented: Binding<Bool> {
        Binding(get: { prompt != nil }, set: { if !$0 { prompt = nil } })
    }

    private var errorIsPresented: Binding<Bool> {
        Binding(get: { session.lastError != nil }, set: { if !$0 { session.lastError = nil } })
    }
}

import SwiftUI

struct NewProjectSheet: View {
    @Environment(ProjectStore.self) private var store
    @Environment(\.dismiss) private var dismiss

    let onCreate: (ProjectRef) -> Void

    @State private var name = ""
    @State private var bundleID = ""
    @State private var templateID = ProjectTemplates.all.first?.id ?? "blank"
    @State private var errorMessage: String?

    private var template: ProjectTemplate {
        ProjectTemplates.all.first { $0.id == templateID } ?? ProjectTemplates.blank
    }

    private var suggestedBundleID: String {
        "com.example." + ProjectManifest.moduleName(from: name.isEmpty ? "MyApp" : name)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("App") {
                    TextField("Name", text: $name)
                        .textInputAutocapitalization(.words)
                    TextField(suggestedBundleID, text: $bundleID)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }

                Section("Template") {
                    ForEach(ProjectTemplates.all) { item in
                        Button {
                            templateID = item.id
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: item.symbol)
                                    .font(.title3)
                                    .frame(width: 32)
                                    .foregroundStyle(.tint)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.title).foregroundStyle(.primary)
                                    Text(item.subtitle)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                if item.id == templateID {
                                    Image(systemName: "checkmark").foregroundStyle(.tint)
                                }
                            }
                        }
                    }
                }

                if let errorMessage {
                    Section { Text(errorMessage).foregroundStyle(.red) }
                }
            }
            .navigationTitle("New Project")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create", action: create)
                        .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private func create() {
        do {
            let ref = try store.create(name: name,
                                       bundleID: bundleID.isEmpty ? nil : bundleID,
                                       template: template)
            dismiss()
            onCreate(ref)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

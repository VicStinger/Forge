import SwiftUI

/// GitHub repository + access token used for cloud builds.
struct BuildSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(BuildConfiguration.repoKey) private var repoText = ""
    @State private var token = ""
    @State private var check: Check = .idle

    private enum Check: Equatable {
        case idle
        case checking
        case ok(String)
        case warning(String)
        case failed(String)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("owner/repository", text: $repoText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    SecureField("Access token", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("GitHub")
                } footer: {
                    Text("The token is kept in this device's Keychain and only ever sent to api.github.com.")
                }

                Section {
                    Button {
                        Task { await testConnection() }
                    } label: {
                        HStack {
                            Text("Test Connection")
                            Spacer()
                            if check == .checking { ProgressView() }
                        }
                    }
                    .disabled(repoText.isEmpty || token.isEmpty || check == .checking)

                    switch check {
                    case .ok(let message):
                        Label(message, systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                    case .warning(let message):
                        Label(message, systemImage: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                    case .failed(let message):
                        Label(message, systemImage: "xmark.octagon.fill").foregroundStyle(.red)
                    case .idle, .checking:
                        EmptyView()
                    }
                }

                Section("Setup") {
                    step(1, "On github.com, create a repository with “Add a README file” ticked. Private is recommended.")
                    step(2, "Create a fine-grained access token limited to that repository, with Read and write access to Contents, Actions and Workflows.")
                    step(3, "Paste the repository and token above, then tap Test Connection.")
                }

                Section("Good to know") {
                    Text("Builds run on GitHub's macOS runners. Public repositories are free. On private repositories each build uses your plan's macOS minutes, which count ten times.")
                    Text("In a public repository your source code and build logs are visible to anyone who finds the run. Use a private repository for anything you don't want public.")
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
            .navigationTitle("Build Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        Keychain.write(token.trimmingCharacters(in: .whitespacesAndNewlines),
                                       account: BuildConfiguration.tokenAccount)
                        dismiss()
                    }
                }
            }
            .onAppear { token = Keychain.read(BuildConfiguration.tokenAccount) ?? "" }
        }
    }

    private func step(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text("\(number)")
                .font(.caption.bold())
                .frame(width: 22, height: 22)
                .background(Color.accentColor.opacity(0.15), in: Circle())
            Text(text).font(.subheadline)
        }
    }

    private func testConnection() async {
        let cleanToken = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let repo = GitHubRepo(repoText) else {
            check = .failed("Enter the repository as owner/name, for example jane/forge-builds.")
            return
        }
        Keychain.write(cleanToken, account: BuildConfiguration.tokenAccount)
        repoText = repo.fullName
        check = .checking

        do {
            let info = try await GitHubClient(repo: repo, token: cleanToken).verify()
            if info.permissions?.push == false {
                check = .failed("Connected to \(info.fullName), but this token can't write to it.")
            } else if !info.private {
                check = .warning("Connected to \(info.fullName). It is public, so builds of your code will be visible to everyone.")
            } else {
                check = .ok("Connected to \(info.fullName) (private).")
            }
        } catch {
            check = .failed(error.localizedDescription)
        }
    }
}

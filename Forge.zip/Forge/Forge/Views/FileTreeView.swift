import SwiftUI

/// What the name-entry alert is currently asking for.
enum FilePrompt: Identifiable {
    case newFile(folder: URL)
    case newFolder(folder: URL)
    case rename(url: URL, currentName: String)

    var id: String {
        switch self {
        case .newFile(let f): return "file-\(f.path)"
        case .newFolder(let f): return "folder-\(f.path)"
        case .rename(let u, _): return "rename-\(u.path)"
        }
    }

    var title: String {
        switch self {
        case .newFile: return "New File"
        case .newFolder: return "New Folder"
        case .rename: return "Rename"
        }
    }

    var message: String {
        switch self {
        case .newFile: return "Include the extension, e.g. Settings.swift"
        case .newFolder: return "Folder names are used as-is in the Xcode project."
        case .rename: return ""
        }
    }

    var confirmTitle: String {
        if case .rename = self { return "Rename" }
        return "Create"
    }

    var initialText: String {
        if case .rename(_, let name) = self { return name }
        return ""
    }
}

/// The project navigator: a collapsible tree of the project's files.
struct FileTreeView: View {
    let session: ProjectSession
    @Binding var selection: URL?
    @Binding var prompt: FilePrompt?

    var body: some View {
        List(session.tree, children: \.children, selection: $selection) { node in
            Label(node.name, systemImage: node.symbolName)
                .lineLimit(1)
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) {
                        session.delete(node.url)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                    Button {
                        prompt = .rename(url: node.url, currentName: node.name)
                    } label: {
                        Label("Rename", systemImage: "pencil")
                    }
                    .tint(.orange)
                }
                .contextMenu {
                    if node.isDirectory {
                        Button {
                            prompt = .newFile(folder: node.url)
                        } label: {
                            Label("New File", systemImage: "doc.badge.plus")
                        }
                        Button {
                            prompt = .newFolder(folder: node.url)
                        } label: {
                            Label("New Folder", systemImage: "folder.badge.plus")
                        }
                    }
                    Button {
                        prompt = .rename(url: node.url, currentName: node.name)
                    } label: {
                        Label("Rename", systemImage: "pencil")
                    }
                    Button(role: .destructive) {
                        session.delete(node.url)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
        }
        .listStyle(.sidebar)
        .overlay {
            if session.tree.isEmpty {
                ContentUnavailableView("No Files", systemImage: "doc",
                                       description: Text("Tap + to add a file."))
            }
        }
    }
}

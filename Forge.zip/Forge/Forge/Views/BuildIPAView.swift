import SwiftUI

/// Starts a cloud build and shows its progress, the resulting IPA, or the compiler errors.
struct BuildIPAView: View {
    let service: BuildService
    let manifest: ProjectManifest
    let sourcesDirectory: URL
    /// Called when the user taps a compiler message; the host opens the file at that line.
    let onSelect: (BuildDiagnostic) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var showingSettings = false
    @State private var shareItem: ShareItem?
    @State private var filesExport: ShareItem?

    private static let liveContainerDocs = URL(string: "https://livecontainer.github.io/docs/intro")!

    var body: some View {
        NavigationStack {
            List {
                statusSection

                if !service.diagnostics.isEmpty {
                    Section("Compiler messages") {
                        ForEach(service.diagnostics) { diagnostic in
                            diagnosticRow(diagnostic)
                        }
                    }
                }

                if let runURL = service.runURL {
                    Section {
                        Link(destination: runURL) {
                            Label("View run on GitHub", systemImage: "arrow.up.right.square")
                        }
                    }
                }
            }
            .navigationTitle("Build IPA")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button { showingSettings = true } label: {
                        Label("Build Settings", systemImage: "gearshape")
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .sheet(isPresented: $showingSettings) { BuildSettingsView() }
            .sheet(item: $shareItem) { item in ShareSheet(url: item.url) }
            .sheet(item: $filesExport) { item in FilesExportPicker(url: item.url) }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: Status

    @ViewBuilder
    private var statusSection: some View {
        switch service.phase {
        case .idle:
            Section {
                if BuildConfiguration.isConfigured {
                    Button {
                        service.start(manifest: manifest, sourcesDirectory: sourcesDirectory)
                    } label: {
                        Label("Build Unsigned IPA", systemImage: "hammer.fill")
                    }
                } else {
                    Label("GitHub isn't set up yet.", systemImage: "link.badge.plus")
                    Button("Set Up GitHub…") { showingSettings = true }
                }
            } footer: {
                Text("Your project is built on a GitHub macOS runner, which takes a few minutes. The IPA is unsigned: re-sign it with a tool such as AltStore or Sideloadly, or your own certificate, before installing it on a device.")
            }

        case .uploading(let done, let total):
            Section {
                if total > 0 {
                    ProgressView(service.statusText, value: Double(done), total: Double(total))
                } else {
                    HStack(spacing: 12) { ProgressView(); Text(service.statusText) }
                }
                cancelButton
            }

        case .waitingForRunner, .building, .downloading:
            Section {
                HStack(spacing: 12) { ProgressView(); Text(service.statusText) }
                cancelButton
            } footer: {
                Text("You can close this sheet. The build keeps running and the hammer icon shows its progress.")
            }

        case .succeeded:
            Section {
                Label("Build succeeded", systemImage: "checkmark.seal.fill")
                    .foregroundStyle(.green)
                if let ipa = service.ipaURL {
                    Button {
                        shareItem = ShareItem(url: ipa)
                    } label: {
                        Label("Share \(ipa.lastPathComponent)", systemImage: "square.and.arrow.up")
                    }
                    Button {
                        filesExport = ShareItem(url: ipa)
                    } label: {
                        Label("Save IPA to Files…", systemImage: "folder.badge.plus")
                    }
                    Link(destination: Self.liveContainerDocs) {
                        Label("About LiveContainer", systemImage: "shippingbox")
                    }
                }
                rebuildButton
            } footer: {
                Text("Unsigned IPA. Re-sign it before installing on a device, or run it in LiveContainer: save the IPA to Files, then tap + in LiveContainer and pick it. LiveContainer skips signing when JIT is enabled and otherwise signs the app with its own certificate. Forge can't run apps itself.")
            }

        case .failed(let message):
            Section {
                Label(message, systemImage: "xmark.octagon.fill")
                    .foregroundStyle(.red)
                if message.hasPrefix("Add your GitHub") {
                    Button("Set Up GitHub…") { showingSettings = true }
                } else {
                    rebuildButton
                }
            }

        case .cancelled:
            Section {
                Label("Build cancelled", systemImage: "stop.circle")
                rebuildButton
            }
        }
    }

    private var cancelButton: some View {
        Button("Cancel Build", role: .destructive) { service.cancel() }
    }

    private var rebuildButton: some View {
        Button {
            service.reset()
            service.start(manifest: manifest, sourcesDirectory: sourcesDirectory)
        } label: {
            Label("Build Again", systemImage: "arrow.clockwise")
        }
    }

    // MARK: Compiler messages

    private func diagnosticRow(_ d: BuildDiagnostic) -> some View {
        Button {
            guard d.path != nil else { return }
            onSelect(d)
            dismiss()
        } label: {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: d.severity == .error
                      ? "xmark.octagon.fill" : "exclamationmark.triangle.fill")
                    .foregroundStyle(d.severity == .error ? .red : .yellow)
                VStack(alignment: .leading, spacing: 2) {
                    Text(d.message).foregroundStyle(.primary)
                    if let path = d.path {
                        Text("\(path):\(d.line):\(d.column)")
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .disabled(d.path == nil)
    }
}

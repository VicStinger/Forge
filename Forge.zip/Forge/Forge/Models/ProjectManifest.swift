import Foundation

/// Metadata stored in `forge.json` at the root of every on-device project.
struct ProjectManifest: Codable, Equatable, Hashable {

    /// Where the project came from, which decides how it is exported and built.
    enum Origin: String, Codable {
        /// Created in Forge (or imported as bare Swift files). Forge writes the `.xcodeproj` on export.
        case generated
        /// An existing Xcode project that was imported. Its files are kept exactly as they were.
        case imported
    }

    var name: String
    var bundleID: String
    var deploymentTarget: String
    var version: String
    var createdAt: Date

    var origin: Origin
    /// Imported projects only: path of the `.xcodeproj` / `.xcworkspace` relative to the project root.
    var buildContainer: String?
    /// Imported projects only: scheme to build. When empty, the first scheme the project lists is used.
    var scheme: String?

    init(name: String,
         bundleID: String? = nil,
         deploymentTarget: String = "17.0",
         version: String = "1.0",
         createdAt: Date = Date(),
         origin: Origin = .generated,
         buildContainer: String? = nil,
         scheme: String? = nil) {
        self.name = name
        self.bundleID = bundleID ?? "com.example.\(ProjectManifest.moduleName(from: name))"
        self.deploymentTarget = deploymentTarget
        self.version = version
        self.createdAt = createdAt
        self.origin = origin
        self.buildContainer = buildContainer
        self.scheme = scheme
    }

    // Projects saved before imports existed have no origin / container / scheme keys.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = try c.decode(String.self, forKey: .name)
        bundleID = try c.decode(String.self, forKey: .bundleID)
        deploymentTarget = try c.decode(String.self, forKey: .deploymentTarget)
        version = try c.decode(String.self, forKey: .version)
        createdAt = try c.decode(Date.self, forKey: .createdAt)
        origin = try c.decodeIfPresent(Origin.self, forKey: .origin) ?? .generated
        buildContainer = try c.decodeIfPresent(String.self, forKey: .buildContainer)
        scheme = try c.decodeIfPresent(String.self, forKey: .scheme)
    }

    var isImported: Bool { origin == .imported }

    /// A name that is safe to use as a Swift module / Xcode target / folder name.
    var moduleName: String { ProjectManifest.moduleName(from: name) }

    static func moduleName(from raw: String) -> String {
        var out = ""
        for ch in raw {
            if ch.isLetter || ch.isNumber || ch == "_" {
                out.append(ch)
            } else if ch == " " || ch == "-" {
                continue
            }
        }
        if out.isEmpty { out = "App" }
        if let first = out.first, first.isNumber { out = "App" + out }
        return out
    }
}

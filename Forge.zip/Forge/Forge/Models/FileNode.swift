import Foundation

/// One entry in the project navigator tree.
/// `children == nil` means "file"; an empty array means "empty folder".
struct FileNode: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    var children: [FileNode]?

    var id: URL { url }
    var name: String { url.lastPathComponent }

    var symbolName: String {
        if isDirectory { return "folder" }
        switch url.pathExtension.lowercased() {
        case "swift": return "swift"
        case "json", "plist": return "curlybraces"
        case "md", "txt": return "doc.text"
        case "png", "jpg", "jpeg", "pdf": return "photo"
        default: return "doc"
        }
    }

    /// Build a tree by walking `root` on disk. Hidden files are skipped.
    static func tree(at root: URL, fileManager fm: FileManager = .default) -> [FileNode] {
        guard let items = try? fm.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return [] }

        let nodes: [FileNode] = items.map { url in
            let isDir = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            return FileNode(url: url,
                            isDirectory: isDir,
                            children: isDir ? tree(at: url, fileManager: fm) : nil)
        }
        // Folders first, then alphabetical.
        return nodes.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
}

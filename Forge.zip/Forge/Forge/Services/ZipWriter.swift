import Foundation

/// Minimal ZIP writer using the "stored" method (no compression).
/// Source projects are small text files, so this is plenty and has no
/// dependency on zlib or on platform-specific archive APIs.
struct ZipWriter {
    private struct Entry {
        let path: String
        let crc: UInt32
        let size: UInt32
        let offset: UInt32
        let dosTime: UInt16
        let dosDate: UInt16
    }

    private var body = Data()
    private var entries: [Entry] = []

    // MARK: CRC-32

    private static let crcTable: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }

    static func crc32(_ data: Data) -> UInt32 {
        var c: UInt32 = 0xFFFF_FFFF
        for b in data { c = crcTable[Int((c ^ UInt32(b)) & 0xFF)] ^ (c >> 8) }
        return c ^ 0xFFFF_FFFF
    }

    // MARK: Little-endian helpers

    private static func le16(_ v: UInt16) -> Data { Data([UInt8(v & 0xFF), UInt8(v >> 8)]) }
    private static func le32(_ v: UInt32) -> Data {
        Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF), UInt8((v >> 16) & 0xFF), UInt8(v >> 24)])
    }

    // MARK: API

    /// Add a file. `path` uses forward slashes and must be relative.
    mutating func addFile(path: String, contents: Data, modified: Date = Date()) {
        let name = Data(path.utf8)
        let (dosTime, dosDate) = Self.dosDateTime(modified)
        let crc = Self.crc32(contents)
        let offset = UInt32(body.count)

        body.append(Self.le32(0x0403_4B50))       // local file header signature
        body.append(Self.le16(20))                // version needed
        body.append(Self.le16(0x0800))            // flags: UTF-8 names
        body.append(Self.le16(0))                 // method: stored
        body.append(Self.le16(dosTime))
        body.append(Self.le16(dosDate))
        body.append(Self.le32(crc))
        body.append(Self.le32(UInt32(contents.count)))  // compressed size
        body.append(Self.le32(UInt32(contents.count)))  // uncompressed size
        body.append(Self.le16(UInt16(name.count)))
        body.append(Self.le16(0))                 // extra length
        body.append(name)
        body.append(contents)

        entries.append(Entry(path: path, crc: crc, size: UInt32(contents.count),
                             offset: offset, dosTime: dosTime, dosDate: dosDate))
    }

    /// Finish the archive and return its bytes.
    func finalize() -> Data {
        var out = body
        let cdStart = UInt32(out.count)

        for e in entries {
            let name = Data(e.path.utf8)
            out.append(Self.le32(0x0201_4B50))    // central directory signature
            out.append(Self.le16(0x031E))         // version made by (Unix, 3.0)
            out.append(Self.le16(20))             // version needed
            out.append(Self.le16(0x0800))         // flags: UTF-8
            out.append(Self.le16(0))              // method: stored
            out.append(Self.le16(e.dosTime))
            out.append(Self.le16(e.dosDate))
            out.append(Self.le32(e.crc))
            out.append(Self.le32(e.size))
            out.append(Self.le32(e.size))
            out.append(Self.le16(UInt16(name.count)))
            out.append(Self.le16(0))              // extra length
            out.append(Self.le16(0))              // comment length
            out.append(Self.le16(0))              // disk number
            out.append(Self.le16(0))              // internal attrs
            out.append(Self.le32(0x81A4_0000))    // external attrs: -rw-r--r--
            out.append(Self.le32(e.offset))
            out.append(name)
        }

        let cdSize = UInt32(out.count) - cdStart
        out.append(Self.le32(0x0605_4B50))        // end of central directory
        out.append(Self.le16(0))
        out.append(Self.le16(0))
        out.append(Self.le16(UInt16(entries.count)))
        out.append(Self.le16(UInt16(entries.count)))
        out.append(Self.le32(cdSize))
        out.append(Self.le32(cdStart))
        out.append(Self.le16(0))                  // comment length
        return out
    }

    // MARK: DOS time

    private static func dosDateTime(_ date: Date) -> (UInt16, UInt16) {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(secondsFromGMT: 0) ?? .current
        let c = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
        let year = max((c.year ?? 1980) - 1980, 0)
        let date16 = UInt16((year << 9) | ((c.month ?? 1) << 5) | (c.day ?? 1))
        let time16 = UInt16(((c.hour ?? 0) << 11) | ((c.minute ?? 0) << 5) | ((c.second ?? 0) / 2))
        return (time16, date16)
    }
}

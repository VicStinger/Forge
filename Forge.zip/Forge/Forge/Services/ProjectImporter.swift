import Foundation

/// Brings an existing project into Forge from a folder or a `.zip` the user picked in the Files app.
///
/// Importing happens in two steps so the slow part can run off the main thread:
/// `stage(from:)` copies / unzips into a temporary folder and inspects it (no shared state touched);
/// `ProjectStore.adopt(_:)` then moves the result into the Projects folder.
enum ProjectImporter {

    struct Staged {
        /// Temporary folder holding everything; deleted once the import is adopted or abandoned.
        let stagingDirectory: URL
        /// The folder inside `stagingDirectory` that becomes the project's `Sources`.
        let sourcesRoot: URL
        let manifest: ProjectManifest
        /// Something worth telling the user, e.g. that no Xcode project was found.
        let note: String?
    }

    enum ImportError: LocalizedError {
        case unsupported(String)
        case pickedProjectItself
        case unsafeArchive
        case tooLarge
        case nothingToImport

        var errorDescription: String? {
            switch self {
            case .unsupported(let name):
                return "“\(name)” isn't a folder or a .zip file."
            case .pickedProjectItself:
                return "Pick the folder that contains the .xcodeproj, or a zip of it, rather than the .xcodeproj itself. The project's source files live next to it."
            case .unsafeArchive:
                return "The zip contains paths that would escape the project folder, so it wasn't imported."
            case .tooLarge:
                return "That project is too large to import. The limit is \(ProjectImporter.maxFileCount) files or \(ProjectImporter.maxTotalBytes / 1_048_576) MB."
            case .nothingToImport:
                return "No Xcode project or Swift files were found in that folder or zip."
            }
        }
    }

    static let maxFileCount = 20_000
    static let maxTotalBytes = 400 * 1024 * 1024

    // MARK: Step 1: stage

    static func stage(from source: URL, fileManager fm: FileManager = .default) throws -> Staged {
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }

        let ext = source.pathExtension.lowercased()
        if ext == "xcodeproj" || ext == "xcworkspace" { throw ImportError.pickedProjectItself }

        let staging = fm.temporaryDirectory.appendingPathComponent("import-\(UUID().uuidString)", isDirectory: true)
        let tree = staging.appendingPathComponent("tree", isDirectory: true)
        try fm.createDirectory(at: tree, withIntermediateDirectories: true)

        do {
            let isDirectory = (try? source.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let fallbackName: String
            if isDirectory {
                var budget = Budget()
                try coordinatedRead(source) { try copyTree(from: $0, to: tree, budget: &budget, fileManager: fm) }
                fallbackName = source.lastPathComponent
            } else if ext == "zip" {
                try unzip(source, to: tree, fileManager: fm)
                fallbackName = source.deletingPathExtension().lastPathComponent
            } else {
                throw ImportError.unsupported(source.lastPathComponent)
            }
            return try analyze(tree: tree, staging: staging, fallbackName: fallbackName)
        } catch {
            try? fm.removeItem(at: staging)
            throw error
        }
    }

    // MARK: Inspecting

    private static func analyze(tree: URL, staging: URL, fallbackName: String) throws -> Staged {
        let root = ProjectDetection.unwrapped(tree)
        // After unwrapping, the folder's own name is the best hint; otherwise use what the user picked.
        let hint = root == tree ? fallbackName : root.lastPathComponent
        let container = ProjectDetection.findContainer(in: root, preferredName: hint)

        if let container {
            let base = ((container as NSString).lastPathComponent as NSString).deletingPathExtension
            let meta = ProjectDetection.metadata(forContainer: container, in: root)
            let manifest = ProjectManifest(
                name: base.isEmpty ? cleanName(fallbackName) : base,
                bundleID: meta.bundleID,
                deploymentTarget: meta.deploymentTarget ?? "17.0",
                origin: .imported,
                buildContainer: container)
            return Staged(stagingDirectory: staging, sourcesRoot: root, manifest: manifest, note: nil)
        }

        guard ProjectDetection.containsSwiftFiles(in: root) else { throw ImportError.nothingToImport }

        // No .xcodeproj: treat the folder as loose Swift sources. Forge writes the project on export.
        let name = root == tree ? cleanName(fallbackName) : cleanName(root.lastPathComponent)
        return Staged(
            stagingDirectory: staging,
            sourcesRoot: root,
            manifest: ProjectManifest(name: name),
            note: "No Xcode project was found, so the Swift files were imported into a new Forge project. Export it to get an Xcode project. If the folder has its own Info.plist, Package.swift or tests, remove them before building.")
    }

    private static func cleanName(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "Imported App" : trimmed
    }

    // MARK: Folder copy

    private struct Budget {
        var files = 0
        var bytes = 0
    }

    private static func copyTree(from src: URL, to dst: URL, budget: inout Budget, fileManager fm: FileManager) throws {
        let items = try fm.contentsOfDirectory(
            at: src,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey],
            options: [])

        for item in items {
            let name = item.lastPathComponent
            if ProjectDetection.isIgnored(name) { continue }

            let values = try item.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey])
            if values.isSymbolicLink == true { continue }

            let target = dst.appendingPathComponent(name)
            if values.isDirectory == true {
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
                try copyTree(from: item, to: target, budget: &budget, fileManager: fm)
            } else {
                budget.files += 1
                budget.bytes += values.fileSize ?? 0
                guard budget.files <= maxFileCount, budget.bytes <= maxTotalBytes else { throw ImportError.tooLarge }
                try fm.copyItem(at: item, to: target)
            }
        }
    }

    // MARK: Zip

    private static func unzip(_ zipURL: URL, to destination: URL, fileManager fm: FileManager) throws {
        let data = try coordinatedRead(zipURL) { try Data(contentsOf: $0, options: .mappedIfSafe) }
        let reader = try ZipReader(data: data)
        let base = destination.standardizedFileURL.path

        var files = 0
        var bytes = 0
        for entry in reader.entries {
            if entry.isDirectory || entry.isSymlink { continue }
            guard let components = safeComponents(entry.name) else { throw ImportError.unsafeArchive }
            if components.contains(where: ProjectDetection.isIgnored) { continue }

            files += 1
            bytes += entry.uncompressedSize
            guard files <= maxFileCount, bytes <= maxTotalBytes else { throw ImportError.tooLarge }

            let target = components.reduce(destination) { $0.appendingPathComponent($1) }
            // Belt and braces against zip-slip, on top of rejecting ".." above.
            guard target.standardizedFileURL.path.hasPrefix(base + "/") else { throw ImportError.unsafeArchive }

            try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            try reader.extract(entry).write(to: target, options: .atomic)
        }
    }

    /// Splits an archive path into components, or returns nil if it could escape the destination.
    static func safeComponents(_ path: String) -> [String]? {
        if path.hasPrefix("/") || path.contains("\\") || path.contains("\0") { return nil }
        var parts: [String] = []
        for piece in path.split(separator: "/", omittingEmptySubsequences: true) {
            if piece == ".." { return nil }
            if piece == "." { continue }
            parts.append(String(piece))
        }
        return parts.isEmpty ? nil : parts
    }

    // MARK: File coordination

    /// Runs `body` inside a coordinated read, which asks the file provider (iCloud Drive etc.) to make the item current.
    private static func coordinatedRead<T>(_ url: URL, _ body: (URL) throws -> T) throws -> T {
        // `body` is non-escaping, and the coordinator's accessor block is not guaranteed to be
        // non-escaping in every SDK, so hand it an escapable copy instead of capturing `body` directly.
        try withoutActuallyEscaping(body) { escapableBody in
            var coordinationError: NSError?
            var outcome: Result<T, Error>?

            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { readURL in
                outcome = Result { try escapableBody(readURL) }
            }

            if let coordinationError { throw coordinationError }
            guard let outcome else { throw ImportError.unsupported(url.lastPathComponent) }
            return try outcome.get()
        }
    }
}

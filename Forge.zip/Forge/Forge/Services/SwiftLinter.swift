import Foundation

struct LintIssue: Identifiable, Hashable {
    enum Severity { case error, warning }

    let severity: Severity
    /// 1-based line and column.
    let line: Int
    let column: Int
    let message: String
    /// UTF-16 offset into the document, used to jump the cursor there.
    let location: Int

    var id: String { "\(location)-\(message)" }
}

/// A lightweight structural check. This is NOT a Swift compiler: it only
/// finds unbalanced brackets and unterminated strings/comments, which is the
/// most common cause of "my whole file is red" while typing on a touch screen.
enum SwiftLinter {

    static func lint(_ text: String) -> [LintIssue] {
        let tokens = SwiftLexer.tokenize(text)
        let lineStarts = Self.lineStarts(of: text)
        var issues: [LintIssue] = []

        func issue(_ severity: LintIssue.Severity, _ offset: Int, _ message: String) -> LintIssue {
            let (line, col) = position(of: offset, lineStarts: lineStarts)
            return LintIssue(severity: severity, line: line, column: col, message: message, location: offset)
        }

        let ns = text as NSString
        var stack: [(char: unichar, offset: Int)] = []

        for token in tokens {
            switch token.kind {
            case .string where !token.isTerminated:
                issues.append(issue(.error, token.range.location, "Unterminated string literal"))
            case .comment where !token.isTerminated:
                issues.append(issue(.error, token.range.location, "Unterminated block comment"))
            case .bracket:
                let ch = ns.character(at: token.range.location)
                switch ch {
                case 40, 91, 123: // ( [ {
                    stack.append((ch, token.range.location))
                default:
                    let wanted: unichar = ch == 41 ? 40 : (ch == 93 ? 91 : 123)
                    if let top = stack.last, top.char == wanted {
                        stack.removeLast()
                    } else if let top = stack.last {
                        issues.append(issue(.error, token.range.location,
                                            "Expected '\(closing(for: top.char))' to match '\(Character(UnicodeScalar(top.char)!))' on line \(position(of: top.offset, lineStarts: lineStarts).0)"))
                        stack.removeLast()
                    } else {
                        issues.append(issue(.error, token.range.location,
                                            "Unexpected '\(Character(UnicodeScalar(ch)!))' with no matching opener"))
                    }
                }
            default:
                break
            }
        }

        for open in stack {
            issues.append(issue(.error, open.offset,
                                "'\(Character(UnicodeScalar(open.char)!))' is never closed"))
        }

        return issues.sorted { $0.location < $1.location }
    }

    // MARK: Helpers

    private static func closing(for open: unichar) -> Character {
        switch open {
        case 40: return ")"
        case 91: return "]"
        default: return "}"
        }
    }

    private static func lineStarts(of text: String) -> [Int] {
        var starts = [0]
        var offset = 0
        for unit in text.utf16 {
            offset += 1
            if unit == 10 { starts.append(offset) }
        }
        return starts
    }

    private static func position(of offset: Int, lineStarts: [Int]) -> (Int, Int) {
        var lo = 0, hi = lineStarts.count - 1
        while lo < hi {
            let mid = (lo + hi + 1) / 2
            if lineStarts[mid] <= offset { lo = mid } else { hi = mid - 1 }
        }
        return (lo + 1, offset - lineStarts[lo] + 1)
    }
}

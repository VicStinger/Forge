import Foundation
import Observation

/// Everything about the project that is currently open in the editor:
/// the file tree, the selected file's text, debounced autosave and lint results.
@MainActor
@Observable
final class ProjectSession {

    private(set) var project: ProjectRef
    private(set) var tree: [FileNode] = []
    private(set) var selectedFile: URL?
    private(set) var text = ""
    private(set) var isBinary = false
    private(set) var issues: [LintIssue] = []
    private(set) var hasUnsavedChanges = false

    private let store: ProjectStore
    @ObservationIgnored private var saveTask: Task<Void, Never>?
    @ObservationIgnored private var lintTask: Task<Void, Never>?

    init(project: ProjectRef, store: ProjectStore) {
        self.project = project
        self.store = store
        reloadTree()
        // Open the first Swift file so the editor is never blank on launch.
        if let first = Self.firstSwiftFile(in: tree) { open(first) }
    }

    var sourcesDirectory: URL { project.sourcesDirectory }

    // MARK: Tree

    func reloadTree() {
        tree = FileNode.tree(at: project.sourcesDirectory)
    }

    func node(for url: URL) -> FileNode? { Self.find(url, in: tree) }

    /// Folder that "New File" / "New Folder" should create into.
    func targetFolder(for selection: URL?) -> URL {
        guard let selection, let node = node(for: selection) else { return sourcesDirectory }
        return node.isDirectory ? node.url : node.url.deletingLastPathComponent()
    }

    // MARK: Opening / editing

    func open(_ url: URL) {
        flushSave()
        selectedFile = url
        if let string = try? String(contentsOf: url, encoding: .utf8) {
            text = string
            isBinary = false
        } else {
            text = ""
            isBinary = true
        }
        hasUnsavedChanges = false
        runLint()
    }

    /// UTF-16 offset of a 1-based line/column in the open file, clamped to that line's text.
    /// (Compilers report columns in UTF-8 bytes, so for non-ASCII lines this is approximate.)
    func utf16Offset(line: Int, column: Int) -> Int {
        let ns = text as NSString
        var lineStart = 0
        var current = 1
        while current < line, lineStart < ns.length {
            var next = 0
            ns.getLineStart(nil, end: &next, contentsEnd: nil, for: NSRange(location: lineStart, length: 0))
            lineStart = next
            current += 1
        }
        guard lineStart < ns.length else { return ns.length }

        var contentsEnd = 0
        ns.getLineStart(nil, end: nil, contentsEnd: &contentsEnd, for: NSRange(location: lineStart, length: 0))
        return min(lineStart + max(column - 1, 0), contentsEnd)
    }

    func setText(_ newValue: String) {
        guard !isBinary, newValue != text else { return }
        text = newValue
        hasUnsavedChanges = true
        scheduleSave()
        scheduleLint()
    }

    func flushSave() {
        saveTask?.cancel()
        saveTask = nil
        guard hasUnsavedChanges, let url = selectedFile, !isBinary else { return }
        do {
            try store.writeFile(url, text: text, in: project)
            hasUnsavedChanges = false
        } catch {
            lastError = error.localizedDescription
        }
    }

    var lastError: String?

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(700))
            guard !Task.isCancelled else { return }
            self?.flushSave()
        }
    }

    private func scheduleLint() {
        lintTask?.cancel()
        lintTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(350))
            guard !Task.isCancelled else { return }
            self?.runLint()
        }
    }

    private func runLint() {
        let isSwift = selectedFile?.pathExtension.lowercased() == "swift"
        issues = (isSwift && !isBinary) ? SwiftLinter.lint(text) : []
    }

    // MARK: File operations

    func createFile(named name: String, in folder: URL) {
        perform {
            let template = name.hasSuffix(".swift") ? "import SwiftUI\n\n" : ""
            let url = try store.createFile(named: name, in: folder, project: project, contents: template)
            reloadTree()
            open(url)
        }
    }

    func createFolder(named name: String, in folder: URL) {
        perform {
            try store.createFolder(named: name, in: folder, project: project)
            reloadTree()
        }
    }

    func rename(_ url: URL, to name: String) {
        perform {
            flushSave()
            let wasSelected = selectedFile == url
            let dest = try store.rename(url, to: name, project: project)
            reloadTree()
            if wasSelected { selectedFile = dest }
            else if let sel = selectedFile, sel.path.hasPrefix(url.path + "/") {
                // A parent folder of the open file was renamed.
                let tail = String(sel.path.dropFirst(url.path.count))
                selectedFile = URL(fileURLWithPath: dest.path + tail)
            }
        }
    }

    func delete(_ url: URL) {
        perform {
            flushSave()
            try store.deleteItem(url, project: project)
            if let sel = selectedFile, sel == url || sel.path.hasPrefix(url.path + "/") {
                selectedFile = nil
                text = ""
                isBinary = false
                issues = []
                hasUnsavedChanges = false
            }
            reloadTree()
        }
    }

    // MARK: Project-level

    func updateManifest(_ manifest: ProjectManifest) {
        perform {
            try store.update(project, manifest: manifest)
            project.manifest = manifest
        }
    }

    /// Builds `<Module>.zip` containing a ready-to-open Xcode project.
    func exportXcodeProject() throws -> URL {
        flushSave()
        return try ProjectExporter.export(manifest: project.manifest, sourcesDir: project.sourcesDirectory)
    }

    // MARK: Helpers

    private func perform(_ work: () throws -> Void) {
        do { try work() } catch { lastError = error.localizedDescription }
    }

    private static func find(_ url: URL, in nodes: [FileNode]) -> FileNode? {
        for node in nodes {
            if node.url.standardizedFileURL == url.standardizedFileURL { return node }
            if let kids = node.children, let hit = find(url, in: kids) { return hit }
        }
        return nil
    }

    private static func firstSwiftFile(in nodes: [FileNode]) -> URL? {
        for node in nodes {
            if !node.isDirectory, node.url.pathExtension == "swift" { return node.url }
            if let kids = node.children, let hit = firstSwiftFile(in: kids) { return hit }
        }
        return nil
    }
}

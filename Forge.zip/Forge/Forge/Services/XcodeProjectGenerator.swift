import Foundation

/// Generates a `project.pbxproj` for a single-target iOS SwiftUI app.
///
/// The project uses Xcode 16's *file-system synchronized groups*
/// (`objectVersion = 77`): the target simply points at a folder, and every
/// file in it is compiled / bundled automatically. That keeps the generated
/// file small and means exported projects never need their file lists
/// regenerated when the user adds files later.
enum XcodeProjectGenerator {

    // MARK: Build setting values

    private enum V: ExpressibleByStringLiteral, ExpressibleByArrayLiteral {
        case s(String)
        case l([String])
        init(stringLiteral value: String) { self = .s(value) }
        init(arrayLiteral elements: String...) { self = .l(elements) }
    }

    // MARK: Public

    static func pbxproj(for manifest: ProjectManifest) -> String {
        let module = manifest.moduleName
        let bundleID = sanitizedBundleID(manifest.bundleID)
        let seed = "forge.\(module)"

        // Object identifiers (deterministic so exports are reproducible).
        let productRef   = id(seed + ".product")
        let mainGroup    = id(seed + ".mainGroup")
        let sourcesGroup = id(seed + ".sourcesGroup")
        let productsGrp  = id(seed + ".productsGroup")
        let target       = id(seed + ".target")
        let project      = id(seed + ".project")
        let srcPhase     = id(seed + ".phase.sources")
        let fwPhase      = id(seed + ".phase.frameworks")
        let resPhase     = id(seed + ".phase.resources")
        let projCfgList  = id(seed + ".cfglist.project")
        let tgtCfgList   = id(seed + ".cfglist.target")
        let projDebug    = id(seed + ".cfg.project.debug")
        let projRelease  = id(seed + ".cfg.project.release")
        let tgtDebug     = id(seed + ".cfg.target.debug")
        let tgtRelease   = id(seed + ".cfg.target.release")

        let q = quote(module)

        var o = ""
        o += "// !$*UTF8*$!\n{\n"
        o += "\tarchiveVersion = 1;\n\tclasses = {\n\t};\n\tobjectVersion = 77;\n\tobjects = {\n\n"

        o += "/* Begin PBXFileReference section */\n"
        o += "\t\t\(productRef) /* \(module).app */ = {isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = \(quote(module + ".app")); sourceTree = BUILT_PRODUCTS_DIR; };\n"
        o += "/* End PBXFileReference section */\n\n"

        o += "/* Begin PBXFileSystemSynchronizedRootGroup section */\n"
        o += "\t\t\(sourcesGroup) /* \(module) */ = {\n\t\t\tisa = PBXFileSystemSynchronizedRootGroup;\n\t\t\tpath = \(q);\n\t\t\tsourceTree = \"<group>\";\n\t\t};\n"
        o += "/* End PBXFileSystemSynchronizedRootGroup section */\n\n"

        o += "/* Begin PBXFrameworksBuildPhase section */\n"
        o += buildPhase(id: fwPhase, isa: "PBXFrameworksBuildPhase", comment: "Frameworks")
        o += "/* End PBXFrameworksBuildPhase section */\n\n"

        o += "/* Begin PBXGroup section */\n"
        o += "\t\t\(mainGroup) = {\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n\t\t\t\t\(sourcesGroup) /* \(module) */,\n\t\t\t\t\(productsGrp) /* Products */,\n\t\t\t);\n\t\t\tsourceTree = \"<group>\";\n\t\t};\n"
        o += "\t\t\(productsGrp) /* Products */ = {\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n\t\t\t\t\(productRef) /* \(module).app */,\n\t\t\t);\n\t\t\tname = Products;\n\t\t\tsourceTree = \"<group>\";\n\t\t};\n"
        o += "/* End PBXGroup section */\n\n"

        o += "/* Begin PBXNativeTarget section */\n"
        o += "\t\t\(target) /* \(module) */ = {\n"
        o += "\t\t\tisa = PBXNativeTarget;\n"
        o += "\t\t\tbuildConfigurationList = \(tgtCfgList) /* Build configuration list for PBXNativeTarget \"\(module)\" */;\n"
        o += "\t\t\tbuildPhases = (\n\t\t\t\t\(srcPhase) /* Sources */,\n\t\t\t\t\(fwPhase) /* Frameworks */,\n\t\t\t\t\(resPhase) /* Resources */,\n\t\t\t);\n"
        o += "\t\t\tbuildRules = (\n\t\t\t);\n\t\t\tdependencies = (\n\t\t\t);\n"
        o += "\t\t\tfileSystemSynchronizedGroups = (\n\t\t\t\t\(sourcesGroup) /* \(module) */,\n\t\t\t);\n"
        o += "\t\t\tname = \(q);\n\t\t\tpackageProductDependencies = (\n\t\t\t);\n\t\t\tproductName = \(q);\n"
        o += "\t\t\tproductReference = \(productRef) /* \(module).app */;\n"
        o += "\t\t\tproductType = \"com.apple.product-type.application\";\n\t\t};\n"
        o += "/* End PBXNativeTarget section */\n\n"

        o += "/* Begin PBXProject section */\n"
        o += "\t\t\(project) /* Project object */ = {\n\t\t\tisa = PBXProject;\n\t\t\tattributes = {\n"
        o += "\t\t\t\tBuildIndependentTargetsInParallel = 1;\n\t\t\t\tLastSwiftUpdateCheck = 1600;\n\t\t\t\tLastUpgradeCheck = 1600;\n"
        o += "\t\t\t\tTargetAttributes = {\n\t\t\t\t\t\(target) = {\n\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;\n\t\t\t\t\t};\n\t\t\t\t};\n\t\t\t};\n"
        o += "\t\t\tbuildConfigurationList = \(projCfgList) /* Build configuration list for PBXProject \"\(module)\" */;\n"
        o += "\t\t\tdevelopmentRegion = en;\n\t\t\thasScannedForEncodings = 0;\n"
        o += "\t\t\tknownRegions = (\n\t\t\t\ten,\n\t\t\t\tBase,\n\t\t\t);\n"
        o += "\t\t\tmainGroup = \(mainGroup);\n\t\t\tminimizedProjectReferenceProxies = 1;\n\t\t\tpreferredProjectObjectVersion = 77;\n"
        o += "\t\t\tproductRefGroup = \(productsGrp) /* Products */;\n\t\t\tprojectDirPath = \"\";\n\t\t\tprojectRoot = \"\";\n"
        o += "\t\t\ttargets = (\n\t\t\t\t\(target) /* \(module) */,\n\t\t\t);\n\t\t};\n"
        o += "/* End PBXProject section */\n\n"

        o += "/* Begin PBXResourcesBuildPhase section */\n"
        o += buildPhase(id: resPhase, isa: "PBXResourcesBuildPhase", comment: "Resources")
        o += "/* End PBXResourcesBuildPhase section */\n\n"

        o += "/* Begin PBXSourcesBuildPhase section */\n"
        o += buildPhase(id: srcPhase, isa: "PBXSourcesBuildPhase", comment: "Sources")
        o += "/* End PBXSourcesBuildPhase section */\n\n"

        o += "/* Begin XCBuildConfiguration section */\n"
        o += config(id: projDebug,   name: "Debug",   settings: projectSettings(debug: true,  manifest: manifest))
        o += config(id: projRelease, name: "Release", settings: projectSettings(debug: false, manifest: manifest))
        o += config(id: tgtDebug,    name: "Debug",   settings: targetSettings(debug: true,  manifest: manifest, bundleID: bundleID))
        o += config(id: tgtRelease,  name: "Release", settings: targetSettings(debug: false, manifest: manifest, bundleID: bundleID))
        o += "/* End XCBuildConfiguration section */\n\n"

        o += "/* Begin XCConfigurationList section */\n"
        o += configList(id: projCfgList, kind: "PBXProject", name: module, debug: projDebug, release: projRelease)
        o += configList(id: tgtCfgList,  kind: "PBXNativeTarget", name: module, debug: tgtDebug, release: tgtRelease)
        o += "/* End XCConfigurationList section */\n"

        o += "\t};\n\trootObject = \(project) /* Project object */;\n}\n"
        return o
    }

    // MARK: Shared scheme

    /// A shared scheme, so `xcodebuild -scheme <Module>` works on a project that Xcode has never opened.
    static func scheme(for manifest: ProjectManifest) -> String {
        let module = manifest.moduleName
        let target = id("forge.\(module).target")

        func reference(_ indent: String) -> String {
            [
                "<BuildableReference",
                "   BuildableIdentifier = \"primary\"",
                "   BlueprintIdentifier = \"\(target)\"",
                "   BuildableName = \"\(module).app\"",
                "   BlueprintName = \"\(module)\"",
                "   ReferencedContainer = \"container:\(module).xcodeproj\">",
                "</BuildableReference>",
            ].map { indent + $0 }.joined(separator: "\n")
        }

        return """
        <?xml version="1.0" encoding="UTF-8"?>
        <Scheme
           LastUpgradeVersion = "1600"
           version = "1.7">
           <BuildAction
              parallelizeBuildables = "YES"
              buildImplicitDependencies = "YES">
              <BuildActionEntries>
                 <BuildActionEntry
                    buildForTesting = "YES"
                    buildForRunning = "YES"
                    buildForProfiling = "YES"
                    buildForArchiving = "YES"
                    buildForAnalyzing = "YES">
        \(reference("           "))
                 </BuildActionEntry>
              </BuildActionEntries>
           </BuildAction>
           <TestAction
              buildConfiguration = "Debug"
              selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
              selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
              shouldUseLaunchSchemeArgsEnv = "YES">
           </TestAction>
           <LaunchAction
              buildConfiguration = "Debug"
              selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
              selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
              launchStyle = "0"
              useCustomWorkingDirectory = "NO"
              ignoresPersistentStateOnLaunch = "NO"
              debugDocumentVersioning = "YES"
              debugServiceExtension = "internal"
              allowLocationSimulation = "YES">
              <BuildableProductRunnable
                 runnableDebuggingMode = "0">
        \(reference("           "))
              </BuildableProductRunnable>
           </LaunchAction>
           <ProfileAction
              buildConfiguration = "Release"
              shouldUseLaunchSchemeArgsEnv = "YES"
              savedToolIdentifier = ""
              useCustomWorkingDirectory = "NO"
              debugDocumentVersioning = "YES">
              <BuildableProductRunnable
                 runnableDebuggingMode = "0">
        \(reference("           "))
              </BuildableProductRunnable>
           </ProfileAction>
           <AnalyzeAction
              buildConfiguration = "Debug">
           </AnalyzeAction>
           <ArchiveAction
              buildConfiguration = "Release"
              revealArchiveInOrganizer = "YES">
           </ArchiveAction>
        </Scheme>
        """
    }

    // MARK: Sections

    private static func buildPhase(id: String, isa: String, comment: String) -> String {
        "\t\t\(id) /* \(comment) */ = {\n\t\t\tisa = \(isa);\n\t\t\tbuildActionMask = 2147483647;\n\t\t\tfiles = (\n\t\t\t);\n\t\t\trunOnlyForDeploymentPostprocessing = 0;\n\t\t};\n"
    }

    private static func config(id: String, name: String, settings: [String: V]) -> String {
        var s = "\t\t\(id) /* \(name) */ = {\n\t\t\tisa = XCBuildConfiguration;\n\t\t\tbuildSettings = {\n"
        for key in settings.keys.sorted() {
            switch settings[key]! {
            case .s(let v):
                s += "\t\t\t\t\(key) = \(quote(v));\n"
            case .l(let items):
                s += "\t\t\t\t\(key) = (\n"
                for item in items { s += "\t\t\t\t\t\(quote(item)),\n" }
                s += "\t\t\t\t);\n"
            }
        }
        s += "\t\t\t};\n\t\t\tname = \(name);\n\t\t};\n"
        return s
    }

    private static func configList(id: String, kind: String, name: String,
                                   debug: String, release: String) -> String {
        "\t\t\(id) /* Build configuration list for \(kind) \"\(name)\" */ = {\n\t\t\tisa = XCConfigurationList;\n\t\t\tbuildConfigurations = (\n\t\t\t\t\(debug) /* Debug */,\n\t\t\t\t\(release) /* Release */,\n\t\t\t);\n\t\t\tdefaultConfigurationIsVisible = 0;\n\t\t\tdefaultConfigurationName = Release;\n\t\t};\n"
    }

    // MARK: Build settings

    private static func projectSettings(debug: Bool, manifest: ProjectManifest) -> [String: V] {
        var s: [String: V] = [
            "ALWAYS_SEARCH_USER_PATHS": "NO",
            "ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS": "YES",
            "CLANG_ANALYZER_NONNULL": "YES",
            "CLANG_ENABLE_MODULES": "YES",
            "CLANG_ENABLE_OBJC_ARC": "YES",
            "CLANG_ENABLE_OBJC_WEAK": "YES",
            "CLANG_WARN_DOCUMENTATION_COMMENTS": "YES",
            "CLANG_WARN_EMPTY_BODY": "YES",
            "CLANG_WARN_UNGUARDED_AVAILABILITY": "YES_AGGRESSIVE",
            "ENABLE_STRICT_OBJC_MSGSEND": "YES",
            "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
            "GCC_C_LANGUAGE_STANDARD": "gnu17",
            "GCC_NO_COMMON_BLOCKS": "YES",
            "GCC_WARN_UNUSED_VARIABLE": "YES",
            "IPHONEOS_DEPLOYMENT_TARGET": .s(manifest.deploymentTarget),
            "LOCALIZATION_PREFERS_STRING_CATALOGS": "YES",
            "SDKROOT": "iphoneos",
        ]
        if debug {
            s["COPY_PHASE_STRIP"] = "NO"
            s["DEBUG_INFORMATION_FORMAT"] = "dwarf"
            s["ENABLE_TESTABILITY"] = "YES"
            s["GCC_DYNAMIC_NO_PIC"] = "NO"
            s["GCC_OPTIMIZATION_LEVEL"] = "0"
            s["GCC_PREPROCESSOR_DEFINITIONS"] = ["DEBUG=1", "$(inherited)"]
            s["MTL_ENABLE_DEBUG_INFO"] = "INCLUDE_SOURCE"
            s["ONLY_ACTIVE_ARCH"] = "YES"
            s["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "DEBUG $(inherited)"
            s["SWIFT_OPTIMIZATION_LEVEL"] = "-Onone"
        } else {
            s["COPY_PHASE_STRIP"] = "NO"
            s["DEBUG_INFORMATION_FORMAT"] = "dwarf-with-dsym"
            s["ENABLE_NS_ASSERTIONS"] = "NO"
            s["MTL_ENABLE_DEBUG_INFO"] = "NO"
            s["SWIFT_COMPILATION_MODE"] = "wholemodule"
            s["VALIDATE_PRODUCT"] = "YES"
        }
        return s
    }

    private static func targetSettings(debug: Bool, manifest: ProjectManifest, bundleID: String) -> [String: V] {
        [
            "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
            "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
            "CODE_SIGN_STYLE": "Automatic",
            "CURRENT_PROJECT_VERSION": "1",
            "ENABLE_PREVIEWS": "YES",
            "GENERATE_INFOPLIST_FILE": "YES",
            "INFOPLIST_KEY_CFBundleDisplayName": .s(manifest.name),
            "INFOPLIST_KEY_UIApplicationSceneManifest_Generation": "YES",
            "INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents": "YES",
            "INFOPLIST_KEY_UILaunchScreen_Generation": "YES",
            "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad":
                "UIInterfaceOrientationPortrait UIInterfaceOrientationPortraitUpsideDown UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight",
            "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone":
                "UIInterfaceOrientationPortrait UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight",
            "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
            "MARKETING_VERSION": .s(manifest.version),
            "PRODUCT_BUNDLE_IDENTIFIER": .s(bundleID),
            "PRODUCT_NAME": "$(TARGET_NAME)",
            "SWIFT_EMIT_LOC_STRINGS": "YES",
            "SWIFT_VERSION": "5.0",
            "TARGETED_DEVICE_FAMILY": "1,2",
        ]
    }

    // MARK: Helpers

    static func sanitizedBundleID(_ raw: String) -> String {
        let allowed = raw.filter { $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "." || $0 == "-") }
        return allowed.isEmpty ? "com.example.app" : allowed
    }

    /// Deterministic 24-hex-digit object ID (what Xcode uses).
    static func id(_ seed: String) -> String {
        func fnv(_ s: String) -> UInt64 {
            var h: UInt64 = 0xcbf2_9ce4_8422_2325
            for b in s.utf8 { h ^= UInt64(b); h = h &* 0x0000_0100_0000_01b3 }
            return h
        }
        let a = String(format: "%016llX", fnv(seed))
        let b = String(format: "%016llX", fnv(seed + "#"))
        return a + String(b.prefix(8))
    }

    /// Quote a value for the old-style property list format unless it is a plain token.
    static func quote(_ value: String) -> String {
        let plain = !value.isEmpty && value.unicodeScalars.allSatisfy {
            ($0.value >= 48 && $0.value <= 57) ||   // 0-9
            ($0.value >= 65 && $0.value <= 90) ||   // A-Z
            ($0.value >= 97 && $0.value <= 122) ||  // a-z
            $0 == "_" || $0 == "." || $0 == "/"
        }
        if plain { return value }
        let escaped = value
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "\n", with: "\\n")
        return "\"\(escaped)\""
    }
}

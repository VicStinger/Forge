import Foundation
import Observation

/// A project on disk: `<Documents>/Projects/<folder>/{forge.json, Sources/…}`.
struct ProjectRef: Identifiable, Hashable {
    let id: String               // folder name
    var manifest: ProjectManifest
    let directory: URL
    var sourcesDirectory: URL { directory.appendingPathComponent("Sources", isDirectory: true) }
}

enum StoreError: LocalizedError {
    case invalidName
    case alreadyExists(String)
    case outsideProject

    var errorDescription: String? {
        switch self {
        case .invalidName: return "Names can't be empty, start with a dot, or contain “/” or “:”."
        case .alreadyExists(let n): return "“\(n)” already exists."
        case .outsideProject: return "That location is outside the project."
        }
    }
}

/// Owns the list of projects and all file-system mutations.
@Observable
final class ProjectStore {

    private(set) var projects: [ProjectRef] = []
    let rootURL: URL

    private static let manifestName = "forge.json"
    private var fm: FileManager { .default }

    init(rootURL: URL? = nil) {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.rootURL = rootURL ?? docs.appendingPathComponent("Projects", isDirectory: true)
        try? FileManager.default.createDirectory(at: self.rootURL, withIntermediateDirectories: true)
        reload()
    }

    // MARK: Projects

    func reload() {
        let dirs = (try? fm.contentsOfDirectory(
            at: rootURL, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]
        )) ?? []

        projects = dirs.compactMap { dir -> ProjectRef? in
            guard let data = try? Data(contentsOf: dir.appendingPathComponent(Self.manifestName)),
                  let manifest = try? Self.decoder.decode(ProjectManifest.self, from: data)
            else { return nil }
            return ProjectRef(id: dir.lastPathComponent, manifest: manifest, directory: dir)
        }
        .sorted { $0.manifest.createdAt > $1.manifest.createdAt }
    }

    @discardableResult
    func create(name: String, bundleID: String?, template: ProjectTemplate) throws -> ProjectRef {
        let clean = try Self.validate(name)
        let manifest = ProjectManifest(name: clean, bundleID: bundleID?.isEmpty == true ? nil : bundleID)
        let dir = uniqueDirectory(named: manifest.moduleName)

        try fm.createDirectory(at: dir.appendingPathComponent("Sources"), withIntermediateDirectories: true)
        for (path, text) in template.materialize(for: manifest) {
            let url = dir.appendingPathComponent("Sources").appendingPathComponent(path)
            try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try text.write(to: url, atomically: true, encoding: .utf8)
        }
        try save(manifest, in: dir)
        reload()
        return ProjectRef(id: dir.lastPathComponent, manifest: manifest, directory: dir)
    }

    func update(_ project: ProjectRef, manifest: ProjectManifest) throws {
        try save(manifest, in: project.directory)
        reload()
    }

    func delete(_ project: ProjectRef) throws {
        try fm.removeItem(at: project.directory)
        reload()
    }

    @discardableResult
    func duplicate(_ project: ProjectRef) throws -> ProjectRef {
        var manifest = project.manifest
        manifest.name += " Copy"
        manifest.createdAt = Date()
        let dir = uniqueDirectory(named: manifest.moduleName)
        try fm.copyItem(at: project.directory, to: dir)
        try save(manifest, in: dir)
        reload()
        return ProjectRef(id: dir.lastPathComponent, manifest: manifest, directory: dir)
    }

    /// Moves a staged import into the Projects folder and registers it. The staging folder is always cleaned up.
    @discardableResult
    func adopt(_ staged: ProjectImporter.Staged) throws -> ProjectRef {
        defer { try? fm.removeItem(at: staged.stagingDirectory) }

        let dir = uniqueDirectory(named: staged.manifest.moduleName)
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            try fm.moveItem(at: staged.sourcesRoot, to: dir.appendingPathComponent("Sources", isDirectory: true))
            try save(staged.manifest, in: dir)
        } catch {
            try? fm.removeItem(at: dir)       // don't leave a half-made project behind
            throw error
        }
        reload()
        return ProjectRef(id: dir.lastPathComponent, manifest: staged.manifest, directory: dir)
    }

    // MARK: Files (all paths are checked to stay inside the project's Sources folder)

    func readFile(_ url: URL) -> String {
        (try? String(contentsOf: url, encoding: .utf8)) ?? ""
    }

    func writeFile(_ url: URL, text: String, in project: ProjectRef) throws {
        try ensureInside(url, project)
        try text.write(to: url, atomically: true, encoding: .utf8)
    }

    @discardableResult
    func createFile(named name: String, in folder: URL, project: ProjectRef, contents: String = "") throws -> URL {
        let clean = try Self.validate(name)
        try ensureInside(folder, project)
        let url = folder.appendingPathComponent(clean)
        guard !fm.fileExists(atPath: url.path) else { throw StoreError.alreadyExists(clean) }
        try contents.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    @discardableResult
    func createFolder(named name: String, in folder: URL, project: ProjectRef) throws -> URL {
        let clean = try Self.validate(name)
        try ensureInside(folder, project)
        let url = folder.appendingPathComponent(clean, isDirectory: true)
        guard !fm.fileExists(atPath: url.path) else { throw StoreError.alreadyExists(clean) }
        try fm.createDirectory(at: url, withIntermediateDirectories: false)
        return url
    }

    @discardableResult
    func rename(_ url: URL, to newName: String, project: ProjectRef) throws -> URL {
        let clean = try Self.validate(newName)
        try ensureInside(url, project)
        let dest = url.deletingLastPathComponent().appendingPathComponent(clean)
        guard !fm.fileExists(atPath: dest.path) else { throw StoreError.alreadyExists(clean) }
        try fm.moveItem(at: url, to: dest)
        return dest
    }

    func deleteItem(_ url: URL, project: ProjectRef) throws {
        try ensureInside(url, project)
        guard url.standardizedFileURL != project.sourcesDirectory.standardizedFileURL else {
            throw StoreError.outsideProject
        }
        try fm.removeItem(at: url)
    }

    // MARK: Helpers

    static func validate(_ raw: String) throws -> String {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, !name.hasPrefix("."),
              !name.contains("/"), !name.contains(":"), !name.contains("\0")
        else { throw StoreError.invalidName }
        return name
    }

    private func ensureInside(_ url: URL, _ project: ProjectRef) throws {
        let base = project.sourcesDirectory.standardizedFileURL.path
        let path = url.standardizedFileURL.path
        guard path == base || path.hasPrefix(base + "/") else { throw StoreError.outsideProject }
    }

    private func uniqueDirectory(named base: String) -> URL {
        var candidate = rootURL.appendingPathComponent(base, isDirectory: true)
        var n = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = rootURL.appendingPathComponent("\(base)-\(n)", isDirectory: true)
            n += 1
        }
        return candidate
    }

    private func save(_ manifest: ProjectManifest, in dir: URL) throws {
        let data = try Self.encoder.encode(manifest)
        try data.write(to: dir.appendingPathComponent(Self.manifestName), options: .atomic)
    }

    private static let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        e.dateEncodingStrategy = .iso8601
        return e
    }()

    private static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }()
}

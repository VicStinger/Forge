import Foundation

/// Looks inside an unpacked folder and works out what kind of project it holds.
/// Pure file-system logic with no UI, so it is easy to reason about and test.
enum ProjectDetection {

    /// Names that are never imported or exported: version-control data, OS litter,
    /// per-user Xcode state and build output.
    static let ignoredNames: Set<String> = [
        ".git", ".DS_Store", "__MACOSX", "DerivedData", "xcuserdata", ".build", ".swiftpm"
    ]

    static func isIgnored(_ name: String) -> Bool { ignoredNames.contains(name) }

    /// Folders that are never searched for a project: asset catalogs, bundles and vendored dependencies.
    private static let opaqueExtensions: Set<String> = [
        "xcassets", "framework", "xcframework", "bundle", "app",
        "appiconset", "imageset", "colorset", "lproj"
    ]
    private static let opaqueNames: Set<String> = ["Pods", "Carthage", "node_modules", "vendor"]

    struct Child {
        let url: URL
        let name: String
        let isDirectory: Bool
    }

    /// Direct children of `dir`, hidden files included, ignored names excluded, sorted by name.
    static func children(of dir: URL, fileManager fm: FileManager = .default) -> [Child] {
        let urls = (try? fm.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [])) ?? []

        return urls.compactMap { url -> Child? in
            let name = url.lastPathComponent
            guard !isIgnored(name) else { return nil }
            let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            return Child(url: url, name: name, isDirectory: isDirectory)
        }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    // MARK: Layout

    /// If `root` holds nothing but one folder (typical for zips: `MyApp/…`), return that folder instead.
    static func unwrapped(_ root: URL) -> URL {
        var current = root
        for _ in 0..<2 {
            let kids = children(of: current)
            guard kids.count == 1, kids[0].isDirectory else { break }
            let ext = (kids[0].name as NSString).pathExtension.lowercased()
            if ext == "xcodeproj" || ext == "xcworkspace" { break }
            current = kids[0].url
        }
        return current
    }

    /// Path (relative to `root`) of the `.xcodeproj` or `.xcworkspace` to build, or nil if there is none.
    ///
    /// Searches breadth-first so the shallowest match wins. At one depth a `.xcodeproj` beats a
    /// `.xcworkspace`, and a project named like the root folder beats the others.
    /// - Parameter preferredName: the name of the folder or zip that was imported; a project called the
    ///   same wins a tie. Defaults to the name of `root`.
    static func findContainer(in root: URL, preferredName: String? = nil, maxDepth: Int = 3) -> String? {
        var level: [(url: URL, rel: String)] = [(root, "")]
        let rootName = (preferredName ?? root.lastPathComponent).lowercased()

        for _ in 0...maxDepth {
            var projects: [String] = []
            var workspaces: [String] = []
            var next: [(url: URL, rel: String)] = []

            for (dir, rel) in level {
                for child in children(of: dir) where child.isDirectory {
                    let path = rel.isEmpty ? child.name : "\(rel)/\(child.name)"
                    let ext = (child.name as NSString).pathExtension.lowercased()
                    if ext == "xcodeproj" {
                        projects.append(path)
                    } else if ext == "xcworkspace" {
                        workspaces.append(path)
                    } else if !opaqueExtensions.contains(ext) && !opaqueNames.contains(child.name) {
                        next.append((child.url, path))
                    }
                }
            }

            if let pick = preferred(projects, rootName: rootName) ?? sortedNames(workspaces).first {
                return pick
            }
            if next.isEmpty { break }
            level = next
        }
        return nil
    }

    static func containsSwiftFiles(in root: URL, fileManager fm: FileManager = .default) -> Bool {
        guard let walker = fm.enumerator(at: root, includingPropertiesForKeys: nil, options: []) else { return false }
        for case let url as URL in walker {
            if isIgnored(url.lastPathComponent) {
                walker.skipDescendants()
                continue
            }
            if url.pathExtension.lowercased() == "swift" { return true }
        }
        return false
    }

    // MARK: Metadata

    struct Metadata {
        var bundleID: String?
        var deploymentTarget: String?
    }

    /// Best-effort read of the bundle ID and deployment target from a `.xcodeproj`'s `project.pbxproj`.
    static func metadata(forContainer relativePath: String, in root: URL) -> Metadata {
        guard relativePath.hasSuffix(".xcodeproj") else { return Metadata() }
        let file = root.appendingPathComponent(relativePath).appendingPathComponent("project.pbxproj")
        guard let data = try? Data(contentsOf: file, options: .mappedIfSafe),
              data.count < 20_000_000,
              let text = String(data: data, encoding: .utf8) else { return Metadata() }

        let bundle = firstCapture(#"PRODUCT_BUNDLE_IDENTIFIER = "?([A-Za-z0-9._\-]+)"?;"#, in: text) {
            // Skip test targets.
            $0.lowercased().contains("test")
        }
        let target = firstCapture(#"IPHONEOS_DEPLOYMENT_TARGET = ([0-9]+(?:\.[0-9]+)?);"#, in: text) { _ in false }
        return Metadata(bundleID: bundle, deploymentTarget: target)
    }

    // MARK: Helpers

    private static func preferred(_ candidates: [String], rootName: String) -> String? {
        let sorted = sortedNames(candidates)
        let sameAsRoot = sorted.first {
            (($0 as NSString).lastPathComponent as NSString).deletingPathExtension.lowercased() == rootName
        }
        return sameAsRoot ?? sorted.first
    }

    private static func sortedNames(_ names: [String]) -> [String] {
        names.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    private static func firstCapture(_ pattern: String, in text: String,
                                     skipping: (String) -> Bool) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let ns = text as NSString
        for match in regex.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            let value = ns.substring(with: match.range(at: 1))
            if !skipping(value) { return value }
        }
        return nil
    }
}

import Foundation

/// A starter project. File contents may contain the placeholders
/// `__MODULE__` (target / module name) and `__NAME__` (display name).
struct ProjectTemplate: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let symbol: String
    let files: [String: String]

    /// Resolve placeholders and add the shared asset catalog.
    func materialize(for manifest: ProjectManifest) -> [String: String] {
        var out: [String: String] = [:]
        for (path, text) in files {
            let resolvedPath = path.replacingOccurrences(of: "__MODULE__", with: manifest.moduleName)
            out[resolvedPath] = text
                .replacingOccurrences(of: "__MODULE__", with: manifest.moduleName)
                .replacingOccurrences(of: "__NAME__", with: manifest.name)
        }
        for (path, text) in ProjectTemplates.assetCatalogFiles where out[path] == nil {
            out[path] = text
        }
        return out
    }
}

enum ProjectTemplates {

    static let all: [ProjectTemplate] = [blank, todo, tabs]

    // MARK: Shared asset catalog

    static let assetCatalogFiles: [String: String] = [
        "Assets.xcassets/Contents.json": """
        {
          "info" : {
            "author" : "xcode",
            "version" : 1
          }
        }
        """,
        "Assets.xcassets/AccentColor.colorset/Contents.json": """
        {
          "colors" : [
            {
              "idiom" : "universal"
            }
          ],
          "info" : {
            "author" : "xcode",
            "version" : 1
          }
        }
        """,
        "Assets.xcassets/AppIcon.appiconset/Contents.json": """
        {
          "images" : [
            {
              "idiom" : "universal",
              "platform" : "ios",
              "size" : "1024x1024"
            }
          ],
          "info" : {
            "author" : "xcode",
            "version" : 1
          }
        }
        """,
    ]

    // MARK: Blank

    static let blank = ProjectTemplate(
        id: "blank",
        title: "Blank App",
        subtitle: "A single SwiftUI view.",
        symbol: "square.dashed",
        files: [
            "__MODULE__App.swift": #"""
            import SwiftUI

            @main
            struct __MODULE__App: App {
                var body: some Scene {
                    WindowGroup {
                        ContentView()
                    }
                }
            }
            """#,
            "ContentView.swift": #"""
            import SwiftUI

            struct ContentView: View {
                var body: some View {
                    VStack(spacing: 12) {
                        Image(systemName: "hammer.fill")
                            .font(.system(size: 48))
                            .foregroundStyle(.tint)
                        Text("Hello, __NAME__!")
                            .font(.title2.weight(.semibold))
                    }
                    .padding()
                }
            }

            #Preview {
                ContentView()
            }
            """#,
        ]
    )
}

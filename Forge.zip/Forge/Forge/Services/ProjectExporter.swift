import Foundation

/// Turns an on-device project into a ready-to-open Xcode project, as a zip or as a plain folder.
///
/// Layout of the result:
///
///     <Module>/
///       <Module>.xcodeproj/…     <- written by Forge for generated projects;
///       <Module>/                   for imported projects the original files come back untouched
///       .gitignore
enum ProjectExporter {

    struct ExportFile {
        let path: String   // relative, forward slashes
        let data: Data
    }

    enum ExportError: LocalizedError {
        case emptyProject
        case tooLarge

        var errorDescription: String? {
            switch self {
            case .emptyProject:
                return "The project has no source files to export."
            case .tooLarge:
                return "This project is too large to export from the device (limit \(ProjectImporter.maxTotalBytes / 1_048_576) MB)."
            }
        }
    }

    // MARK: Pure (testable) core

    /// Every file of the exported project, keyed by path relative to the project root.
    ///
    /// - Generated projects: `<Module>.xcodeproj/…`, `<Module>/…` (the sources) and `.gitignore`.
    /// - Imported projects: exactly the files that were imported. Forge never rewrites their `.xcodeproj`.
    ///
    /// The zip export, the folder export and the cloud build upload all use this, so they can't drift apart.
    static func projectFiles(manifest: ProjectManifest, sources: [ExportFile]) throws -> [String: Data] {
        guard !sources.isEmpty else { throw ExportError.emptyProject }

        var all: [String: Data] = [:]

        if manifest.isImported {
            for file in sources { all[file.path] = file.data }
            return all
        }

        let module = manifest.moduleName
        for file in sources {
            all["\(module)/\(file.path)"] = file.data
        }

        // Make sure the asset catalog the generated build settings refer to exists.
        for (path, text) in ProjectTemplates.assetCatalogFiles {
            let full = "\(module)/\(path)"
            if all[full] == nil { all[full] = Data(text.utf8) }
        }

        let proj = "\(module).xcodeproj"
        all["\(proj)/project.pbxproj"] = Data(XcodeProjectGenerator.pbxproj(for: manifest).utf8)
        all["\(proj)/project.xcworkspace/contents.xcworkspacedata"] = Data(workspaceData(module: module).utf8)
        all["\(proj)/xcshareddata/xcschemes/\(module).xcscheme"] = Data(XcodeProjectGenerator.scheme(for: manifest).utf8)
        all[".gitignore"] = Data(gitignore.utf8)
        return all
    }

    /// Build the zip bytes from in-memory files; everything sits inside a `<Module>/` folder.
    static func archive(manifest: ProjectManifest, sources: [ExportFile]) throws -> Data {
        let files = try projectFiles(manifest: manifest, sources: sources)

        var zip = ZipWriter()
        for path in files.keys.sorted() {
            zip.addFile(path: "\(manifest.moduleName)/\(path)", contents: files[path]!)
        }
        return zip.finalize()
    }

    // MARK: Disk-facing

    /// Read `sourcesDir`, build the archive and write `<Module>.zip` into the temp directory.
    static func export(manifest: ProjectManifest, sourcesDir: URL) throws -> URL {
        let files = try collect(sourcesDir: sourcesDir, includeHidden: manifest.isImported)
        let data = try archive(manifest: manifest, sources: files)

        let out = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(manifest.moduleName).zip")
        try? FileManager.default.removeItem(at: out)
        try data.write(to: out, options: .atomic)
        return out
    }

    /// Write the project as an ordinary folder `<Module>/` (not zipped) and return its URL.
    /// The folder can then be saved anywhere in the Files app.
    static func exportFolder(manifest: ProjectManifest, sourcesDir: URL) throws -> URL {
        let fm = FileManager.default
        let files = try projectFiles(
            manifest: manifest,
            sources: collect(sourcesDir: sourcesDir, includeHidden: manifest.isImported))

        // A fresh parent keeps the folder itself named exactly `<Module>`.
        let parent = fm.temporaryDirectory.appendingPathComponent("export-\(UUID().uuidString)", isDirectory: true)
        let root = parent.appendingPathComponent(manifest.moduleName, isDirectory: true)

        for (path, data) in files {
            let url = root.appendingPathComponent(path)
            try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try data.write(to: url, options: .atomic)
        }
        return root
    }

    /// Reads every regular file under `sourcesDir`.
    /// - Parameter includeHidden: imported projects keep dotfiles such as `.gitignore`; generated ones don't have any.
    static func collect(sourcesDir: URL, includeHidden: Bool = false) throws -> [ExportFile] {
        let fm = FileManager.default
        guard let walker = fm.enumerator(
            at: sourcesDir,
            includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey],
            options: includeHidden ? [] : [.skipsHiddenFiles]
        ) else { return [] }

        // Compare path *components* after resolving symlinks, so "/private/var/…" and
        // "/var/…" spellings of the same folder don't produce bogus relative paths.
        let baseComponents = sourcesDir.resolvingSymlinksInPath().pathComponents
        var result: [ExportFile] = []
        var totalBytes = 0

        for case let url as URL in walker {
            // Version-control data, per-user Xcode state and build output never travel with a project.
            if ProjectDetection.isIgnored(url.lastPathComponent) {
                walker.skipDescendants()
                continue
            }

            let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
            guard values.isRegularFile == true else { continue }

            totalBytes += values.fileSize ?? 0
            guard totalBytes <= ProjectImporter.maxTotalBytes else { throw ExportError.tooLarge }

            let components = url.resolvingSymlinksInPath().pathComponents
            guard components.count > baseComponents.count,
                  Array(components.prefix(baseComponents.count)) == baseComponents else { continue }
            let rel = components.dropFirst(baseComponents.count).joined(separator: "/")

            result.append(ExportFile(path: rel, data: try Data(contentsOf: url)))
        }
        return result
    }

    // MARK: Static files

    private static func workspaceData(module: String) -> String {
        """
        <?xml version="1.0" encoding="UTF-8"?>
        <Workspace
           version = "1.0">
           <FileRef
              location = "self:">
           </FileRef>
        </Workspace>
        """
    }

    private static let gitignore = """
    .DS_Store
    xcuserdata/
    DerivedData/
    build/
    *.xcuserstate
    """
}

import Foundation

extension ProjectTemplates {

    // MARK: To-do list

    static let todo = ProjectTemplate(
        id: "todo",
        title: "To-Do List",
        subtitle: "List, add, toggle and delete with @Observable state.",
        symbol: "checklist",
        files: [
            "__MODULE__App.swift": #"""
            import SwiftUI

            @main
            struct __MODULE__App: App {
                @State private var store = TodoStore()

                var body: some Scene {
                    WindowGroup {
                        TodoListView()
                            .environment(store)
                    }
                }
            }
            """#,
            "TodoStore.swift": #"""
            import Foundation
            import Observation

            struct TodoItem: Identifiable, Hashable {
                let id = UUID()
                var title: String
                var isDone = false
            }

            @Observable
            final class TodoStore {
                var items: [TodoItem] = [
                    TodoItem(title: "Open this project in Xcode"),
                    TodoItem(title: "Ship something small"),
                ]

                func add(_ title: String) {
                    let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !trimmed.isEmpty else { return }
                    items.append(TodoItem(title: trimmed))
                }

                func delete(at offsets: IndexSet) {
                    items.remove(atOffsets: offsets)
                }
            }
            """#,
            "TodoListView.swift": #"""
            import SwiftUI

            struct TodoListView: View {
                @Environment(TodoStore.self) private var store
                @State private var newTitle = ""

                var body: some View {
                    @Bindable var store = store

                    NavigationStack {
                        List {
                            Section {
                                HStack {
                                    TextField("New task", text: $newTitle)
                                        .onSubmit(addItem)
                                    Button("Add", action: addItem)
                                        .disabled(newTitle.isEmpty)
                                }
                            }
                            Section {
                                ForEach($store.items) { $item in
                                    Toggle(isOn: $item.isDone) {
                                        Text(item.title)
                                            .strikethrough(item.isDone)
                                    }
                                }
                                .onDelete(perform: store.delete)
                            }
                        }
                        .navigationTitle("__NAME__")
                    }
                }

                private func addItem() {
                    store.add(newTitle)
                    newTitle = ""
                }
            }

            #Preview {
                TodoListView()
                    .environment(TodoStore())
            }
            """#,
        ]
    )

    // MARK: Tab app

    static let tabs = ProjectTemplate(
        id: "tabs",
        title: "Tab App",
        subtitle: "Three tabs with a navigation stack in each.",
        symbol: "square.grid.2x2",
        files: [
            "__MODULE__App.swift": #"""
            import SwiftUI

            @main
            struct __MODULE__App: App {
                var body: some Scene {
                    WindowGroup {
                        RootTabView()
                    }
                }
            }
            """#,
            "RootTabView.swift": #"""
            import SwiftUI

            struct RootTabView: View {
                var body: some View {
                    TabView {
                        NavigationStack {
                            PlaceholderScreen(title: "Home", detail: "Start here.")
                        }
                        .tabItem { Label("Home", systemImage: "house") }

                        NavigationStack {
                            PlaceholderScreen(title: "Explore", detail: "Find something new.")
                        }
                        .tabItem { Label("Explore", systemImage: "safari") }

                        NavigationStack {
                            PlaceholderScreen(title: "Settings", detail: "Tweak things.")
                        }
                        .tabItem { Label("Settings", systemImage: "gearshape") }
                    }
                }
            }

            #Preview {
                RootTabView()
            }
            """#,
            "PlaceholderScreen.swift": #"""
            import SwiftUI

            struct PlaceholderScreen: View {
                let title: String
                let detail: String

                var body: some View {
                    ContentUnavailableView(title, systemImage: "sparkles", description: Text(detail))
                        .navigationTitle(title)
                }
            }
            """#,
        ]
    )
}

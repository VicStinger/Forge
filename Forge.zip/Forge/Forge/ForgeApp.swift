import SwiftUI

@main
struct ForgeApp: App {
    @State private var store = ProjectStore()

    var body: some Scene {
        WindowGroup {
            ProjectListView()
                .environment(store)
        }
    }
}
